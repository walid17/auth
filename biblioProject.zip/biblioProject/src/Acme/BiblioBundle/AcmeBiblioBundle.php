<?php

namespace Acme\BiblioBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeBiblioBundle extends Bundle
{
}

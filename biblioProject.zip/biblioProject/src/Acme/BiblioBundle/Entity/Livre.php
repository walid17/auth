<?php

namespace Acme\BiblioBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;

/**
 * Livre
 *
 * @ORM\Table(name="livre", indexes={@ORM\Index(name="Id_Category", columns={"Id_Category"})})
 * @ORM\Entity
 * @Vich\Uploadable
 */
class Livre
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="acteur", type="string", length=255, nullable=false)
     */
    private $acteur;

    /**
     * @var string
     *
     * @ORM\Column(name="titre", type="string", length=255, nullable=false)
     */
    private $titre;

    

    

    /**
     * @var integer
     *
     * @ORM\Column(name="nbr_page", type="integer", nullable=false)
     */
    private $nbrPage;

    /**
     * @var integer
     *
     * @ORM\Column(name="nbr_download", type="integer", nullable=false)
     */
    private $nbrDownload;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=false)
     */
    private $date;

    /**
     * @var \Acme\BiblioBundle\Entity\Category
     *
     * @ORM\ManyToOne(targetEntity="Acme\BiblioBundle\Entity\Category")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="Id_Category", referencedColumnName="id")
     * })
     */
    private $idCategory;

        /**
     * NOTE: This is not a mapped field of entity metadata, just a simple property.
     * 
     * @Vich\UploadableField(mapping="product_image", fileNameProperty="imageName", size="imageSize")
     * 
     * @var File
     */
    private $imageFile;

            /**
     * NOTE: This is not a mapped field of entity metadata, just a simple property.
     * 
     * @Vich\UploadableField(mapping="product_pdf", fileNameProperty="imageNam", size="imageSiz")
     * 
     * @var File
     */
    private $imageFil;

        /**
     * @ORM\Column(type="string", length=255)
     *
     * @var string
     */
    private $imageNam;

    /**
     * @ORM\Column(type="string", length=255)
     *
     * @var string
     */
    private $imageName;

    private $imageSiz;    
    private $imageSize;

    /**
     * @ORM\Column(type="datetime")
     *
     * @var \DateTime
     */
    private $updatedAt;

    /**
     * If manually uploading a file (i.e. not using Symfony Form) ensure an instance
     * of 'UploadedFile' is injected into this setter to trigger the  update. If this
     * bundle's configuration parameter 'inject_on_load' is set to 'true' this setter
     * must be able to accept an instance of 'File' as the bundle will inject one here
     * during Doctrine hydration.
     *
     * @param File|\Symfony\Component\HttpFoundation\File\UploadedFile $image
     *
     * @return Product
     */
    public function setImageFile(File $image = null)
    {
        $this->imageFile = $image;

        if ($image) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
        
        return $this;
    }

    /**
     * @return File|null
     */
    public function getImageFile()
    {
        return $this->imageFile;
    }

    /**
     * @param string $imageName
     *
     * @return Product
     */
    public function setImageName($imageName)
    {
        $this->imageName = $imageName;
        
        return $this;
    }

    /**
     * @return string|null
     */
    public function getImageName()
    {
        return $this->imageName;
    }
    
    /**
     * @param integer $imageSize
     *
     * @return Product
     */
    public function setImageSize($imageSize)
    {
        $this->imagesize = $imageSize;
        
        return $this;
    }

    /**
     * @return integer|null
     */
    public function getImageSize()
    {
        return $this->imageSize;
    }





    /**
     * If manually uploading a file (i.e. not using Symfony Form) ensure an instance
     * of 'UploadedFile' is injected into this setter to trigger the  update. If this
     * bundle's configuration parameter 'inject_on_load' is set to 'true' this setter
     * must be able to accept an instance of 'File' as the bundle will inject one here
     * during Doctrine hydration.
     *
     * @param File|\Symfony\Component\HttpFoundation\File\UploadedFile $image
     *
     * @return Product
     */
    public function setImageFil(File $image = null)
    {
        $this->imageFil = $image;

        if ($image) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
        
        return $this;
    }

    /**
     * @return File|null
     */
    public function getImageFil()
    {
        return $this->imageFil;
    }

    /**
     * @param string $imageNam
     *
     * @return Product
     */
    public function setImageNam($imageNam)
    {
        $this->imageNam = $imageNam;
        
        return $this;
    }

    /**
     * @return string|null
     */
    public function getImageNam()
    {
        return $this->imageNam;
    }
    
    /**
     * @param integer $imageSiz
     *
     * @return Product
     */
    public function setImageSiz($imageSiz)
    {
        $this->imagesiz = $imageSiz;
        
        return $this;
    }

    /**
     * @return integer|null
     */
    public function getImageSiz()
    {
        return $this->imageSiz;
    }










    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set acteur
     *
     * @param string $acteur
     * @return Livre
     */
    public function setActeur($acteur)
    {
        $this->acteur = $acteur;

        return $this;
    }

    /**
     * Get acteur
     *
     * @return string 
     */
    public function getActeur()
    {
        return $this->acteur;
    }

    /**
     * Set titre
     *
     * @param string $titre
     * @return Livre
     */
    public function setTitre($titre)
    {
        $this->titre = $titre;

        return $this;
    }

    /**
     * Get titre
     *
     * @return string 
     */
    public function getTitre()
    {
        return $this->titre;
    }


    /**
     * Set nbrPage
     *
     * @param integer $nbrPage
     * @return Livre
     */
    public function setNbrPage($nbrPage)
    {
        $this->nbrPage = $nbrPage;

        return $this;
    }

    /**
     * Get nbrPage
     *
     * @return integer 
     */
    public function getNbrPage()
    {
        return $this->nbrPage;
    }

    /**
     * Set nbrDownload
     *
     * @param integer $nbrDownload
     * @return Livre
     */
    public function setNbrDownload($nbrDownload)
    {
        $this->nbrDownload = $nbrDownload;

        return $this;
    }

    /**
     * Get nbrDownload
     *
     * @return integer 
     */
    public function getNbrDownload()
    {
        return $this->nbrDownload;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return Livre
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set idCategory
     *
     * @param \Acme\BiblioBundle\Entity\Category $idCategory
     * @return Livre
     */
    public function setIdCategory(\Acme\BiblioBundle\Entity\Category $idCategory = null)
    {
        $this->idCategory = $idCategory;

        return $this;
    }

    /**
     * Get idCategory
     *
     * @return \Acme\BiblioBundle\Entity\Category 
     */
    public function getIdCategory()
    {
        return $this->idCategory;
    }

        public function __toString()
{
    return $this->getTitre();
}
}

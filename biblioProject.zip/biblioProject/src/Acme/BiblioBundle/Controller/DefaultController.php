<?php

namespace Acme\BiblioBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Acme\BiblioBundle\Entity\Livre;

class DefaultController extends Controller
{
    

    public function indexAction()
    {   //$livre = new Livre();
        $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery(
            'SELECT p
            FROM AcmeBiblioBundle:Livre p
            ORDER BY p.id DESC 
        ');
        $query->setMaxResults(6);
        $products = $query->getResult();

        $query = $em->createQuery(
            'SELECT p
            FROM AcmeBiblioBundle:Livre p
            ORDER BY p.nbrDownload DESC 
        ');
        $query->setMaxResults(5);
        $top = $query->getResult();
        //$livre= $this->getDoctrine()->getManager()->getRepository('AcmeBiblioBundle:Livre')->findAll();
        return $this->render('AcmeBiblioBundle:Default:index.html.twig',array(
            'livre' => $products,'top' => $top));
    }
}



<?php

/* :livre:index.html.twig */
class __TwigTemplate_d0a42eff2f04e396d0dcaea9aca5f14ae8f334e8113ca6711e4f453a2ed51749 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":livre:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_27f838138c826c85c24b4b65000135f2844a3964755042534fc09635c010e10d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27f838138c826c85c24b4b65000135f2844a3964755042534fc09635c010e10d->enter($__internal_27f838138c826c85c24b4b65000135f2844a3964755042534fc09635c010e10d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":livre:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_27f838138c826c85c24b4b65000135f2844a3964755042534fc09635c010e10d->leave($__internal_27f838138c826c85c24b4b65000135f2844a3964755042534fc09635c010e10d_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e6e0c1a7e499bf335252cbc6aa7f1e9fe4cb7f98d384db3947f59191210f544b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6e0c1a7e499bf335252cbc6aa7f1e9fe4cb7f98d384db3947f59191210f544b->enter($__internal_e6e0c1a7e499bf335252cbc6aa7f1e9fe4cb7f98d384db3947f59191210f544b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

  








<h4 class=\"heading_a uk-margin-bottom\">Livres list</h4>
<div class=\"md-card uk-margin-medium-bottom\">
    <div class=\"md-card-content\">
        <div class=\"uk-overflow-container\">
            <table class=\"uk-table uk-table-striped\">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Acteur</th>
                    <th>Titre</th>
                    <th>Photo</th>
                    <th>Pdf</th>
                    <th>Nbrpage</th>
                    <th>Nbrdownload</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>


                 ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["livres"]) ? $context["livres"] : $this->getContext($context, "livres")));
        foreach ($context['_seq'] as $context["_key"] => $context["livre"]) {
            // line 37
            echo "                    <tr>
                        <td><a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_show", array("id" => $this->getAttribute($context["livre"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "id", array()), "html", null, true);
            echo "</a></td>
                        <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "acteur", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "titre", array()), "html", null, true);
            echo "</td>
                        
                          <td>

                            <a href='/images/pdfs/";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "imageNam", array()), "html", null, true);
            echo "' download>
                              <img src=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/template/image/pdf.png"), "html", null, true);
            echo "\" style=\"width: 80px;\">
                            </a>

                            </td>
                             <td>

                            <a href='/images/products/";
            // line 51
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "imageName", array()), "html", null, true);
            echo "'>
                                <img src=\"/images/products/";
            // line 52
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "imageName", array()), "html", null, true);
            echo "\" style=\"width: 80px;\">
                            </a>

                          </td>
                       
                        <td>";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "nbrPage", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 58
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "nbrDownload", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 59
            if ($this->getAttribute($context["livre"], "date", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["livre"], "date", array()), "Y-m-d"), "html", null, true);
            }
            echo "</td>
                        <td>
                          

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\" width: 45px; height: 45px; float: left;\" href=\"";
            // line 63
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_show", array("id" => $this->getAttribute($context["livre"], "id", array()))), "html", null, true);
            echo "\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">remove_red_eye</i>
                                    </a>
  

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\"    background: #4CAF50; width: 45px; height: 45px;float: left; margin-left: 5px; \"  href=\"";
            // line 68
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_edit", array("id" => $this->getAttribute($context["livre"], "id", array()))), "html", null, true);
            echo "\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">edit</i>
                                    </a>
 
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['livre'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "              
                </tbody>
            </table>
        </div>
    </div>
</div>





    <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_new");
        echo "\">
                        <i class=\"material-icons\">add</i>
                        </a>
                     
                    </div>
 
";
        
        $__internal_e6e0c1a7e499bf335252cbc6aa7f1e9fe4cb7f98d384db3947f59191210f544b->leave($__internal_e6e0c1a7e499bf335252cbc6aa7f1e9fe4cb7f98d384db3947f59191210f544b_prof);

    }

    public function getTemplateName()
    {
        return ":livre:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 87,  161 => 75,  148 => 68,  140 => 63,  131 => 59,  127 => 58,  123 => 57,  115 => 52,  111 => 51,  102 => 45,  98 => 44,  91 => 40,  87 => 39,  81 => 38,  78 => 37,  74 => 36,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}


  








<h4 class=\"heading_a uk-margin-bottom\">Livres list</h4>
<div class=\"md-card uk-margin-medium-bottom\">
    <div class=\"md-card-content\">
        <div class=\"uk-overflow-container\">
            <table class=\"uk-table uk-table-striped\">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Acteur</th>
                    <th>Titre</th>
                    <th>Photo</th>
                    <th>Pdf</th>
                    <th>Nbrpage</th>
                    <th>Nbrdownload</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>


                 {% for livre in livres %}
                    <tr>
                        <td><a href=\"{{ path('livre_show', { 'id': livre.id }) }}\">{{ livre.id }}</a></td>
                        <td>{{ livre.acteur }}</td>
                        <td>{{ livre.titre }}</td>
                        
                          <td>

                            <a href='/images/pdfs/{{ livre.imageNam }}' download>
                              <img src=\"{{ asset('/template/image/pdf.png') }}\" style=\"width: 80px;\">
                            </a>

                            </td>
                             <td>

                            <a href='/images/products/{{ livre.imageName }}'>
                                <img src=\"/images/products/{{ livre.imageName }}\" style=\"width: 80px;\">
                            </a>

                          </td>
                       
                        <td>{{ livre.nbrPage }}</td>
                        <td>{{ livre.nbrDownload }}</td>
                        <td>{% if livre.date %}{{ livre.date|date('Y-m-d') }}{% endif %}</td>
                        <td>
                          

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\" width: 45px; height: 45px; float: left;\" href=\"{{ path('livre_show', { 'id': livre.id }) }}\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">remove_red_eye</i>
                                    </a>
  

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\"    background: #4CAF50; width: 45px; height: 45px;float: left; margin-left: 5px; \"  href=\"{{ path('livre_edit', { 'id': livre.id }) }}\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">edit</i>
                                    </a>
 
                        </td>
                    </tr>
                {% endfor %}
              
                </tbody>
            </table>
        </div>
    </div>
</div>





    <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('livre_new') }}\">
                        <i class=\"material-icons\">add</i>
                        </a>
                     
                    </div>
 
{% endblock %}
", ":livre:index.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app/Resources\\views/livre/index.html.twig");
    }
}

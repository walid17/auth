<?php

/* category/edit.html.twig */
class __TwigTemplate_95d7da1042ac5f8eeac13dd51870870928935fa9034f5a6a1984009506e20781 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de1fd14e5c313f0fd9b0711ab13a310b61afc84992664810f9a1f9d3e1e17520 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de1fd14e5c313f0fd9b0711ab13a310b61afc84992664810f9a1f9d3e1e17520->enter($__internal_de1fd14e5c313f0fd9b0711ab13a310b61afc84992664810f9a1f9d3e1e17520_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_de1fd14e5c313f0fd9b0711ab13a310b61afc84992664810f9a1f9d3e1e17520->leave($__internal_de1fd14e5c313f0fd9b0711ab13a310b61afc84992664810f9a1f9d3e1e17520_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_b39ec15ea5cf57f1a419f2be1f3ff40fb2dff9b6b153e016cfbc0ab1168ae479 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b39ec15ea5cf57f1a419f2be1f3ff40fb2dff9b6b153e016cfbc0ab1168ae479->enter($__internal_b39ec15ea5cf57f1a419f2be1f3ff40fb2dff9b6b153e016cfbc0ab1168ae479_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <h1>Modifier Catégories</h1>

 

<div class=\"md-card\">
                            <div class=\"md-card-toolbar\">
                                <h3 class=\"md-card-toolbar-heading-text\">
                                    Details
                                </h3>


                                 <a href=\"#\" style=\" float: right; margin: 10px; \">

             ";
        // line 18
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
             <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
               <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
            </button>

            ";
        // line 23
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "

            
        </a>

                            </div>
                            <div class=\"md-card-content large-padding\">
                                <div class=\"uk-grid uk-grid-divider uk-grid-medium\" data-uk-grid-margin>
                                    <div class=\"uk-width-large-1-1\">
                                     


                    ";
        // line 35
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Name</label>
                                ";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "name", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Description</label>
                                ";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "description", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Type</label>
                                ";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "type", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>

 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Modifier\" />
                          </div>  

                                ";
        // line 64
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "


                                    </div>
                                   
                                </div>
                            </div>
                        </div>

   

 

         <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 78
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>
";
        
        $__internal_b39ec15ea5cf57f1a419f2be1f3ff40fb2dff9b6b153e016cfbc0ab1168ae479->leave($__internal_b39ec15ea5cf57f1a419f2be1f3ff40fb2dff9b6b153e016cfbc0ab1168ae479_prof);

    }

    public function getTemplateName()
    {
        return "category/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 78,  120 => 64,  107 => 54,  96 => 46,  86 => 39,  79 => 35,  64 => 23,  56 => 18,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <h1>Modifier Catégories</h1>

 

<div class=\"md-card\">
                            <div class=\"md-card-toolbar\">
                                <h3 class=\"md-card-toolbar-heading-text\">
                                    Details
                                </h3>


                                 <a href=\"#\" style=\" float: right; margin: 10px; \">

             {{ form_start(delete_form) }}
             <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
               <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
            </button>

            {{ form_end(delete_form) }}

            
        </a>

                            </div>
                            <div class=\"md-card-content large-padding\">
                                <div class=\"uk-grid uk-grid-divider uk-grid-medium\" data-uk-grid-margin>
                                    <div class=\"uk-width-large-1-1\">
                                     


                    {{ form_start(edit_form) }}
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Name</label>
                                {{ form_widget(edit_form.name,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Description</label>
                                {{ form_widget(edit_form.description,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Type</label>
                                {{ form_widget(edit_form.type,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>

 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Modifier\" />
                          </div>  

                                {{ form_end(edit_form) }}


                                    </div>
                                   
                                </div>
                            </div>
                        </div>

   

 

         <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('category_index') }}\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>
{% endblock %}
", "category/edit.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app\\Resources\\views\\category\\edit.html.twig");
    }
}

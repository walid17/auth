<?php

/* @FOSUser/Registration/register.html.twig */
class __TwigTemplate_fb69431a49bd0874530b87abec654f527d8493a85e69219b1515d13a3a833323 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Registration/register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_daaebe48d91fedfe7d6ad8b74f824ac637852ba0f7312bca7d12eeb24f7e4be5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_daaebe48d91fedfe7d6ad8b74f824ac637852ba0f7312bca7d12eeb24f7e4be5->enter($__internal_daaebe48d91fedfe7d6ad8b74f824ac637852ba0f7312bca7d12eeb24f7e4be5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Registration/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_daaebe48d91fedfe7d6ad8b74f824ac637852ba0f7312bca7d12eeb24f7e4be5->leave($__internal_daaebe48d91fedfe7d6ad8b74f824ac637852ba0f7312bca7d12eeb24f7e4be5_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_9c7434cd62bc3bbedaabeb7224f0ca0dd1741c7b57f92fa3420a40a15b321690 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c7434cd62bc3bbedaabeb7224f0ca0dd1741c7b57f92fa3420a40a15b321690->enter($__internal_9c7434cd62bc3bbedaabeb7224f0ca0dd1741c7b57f92fa3420a40a15b321690_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "@FOSUser/Registration/register.html.twig", 4)->display($context);
        
        $__internal_9c7434cd62bc3bbedaabeb7224f0ca0dd1741c7b57f92fa3420a40a15b321690->leave($__internal_9c7434cd62bc3bbedaabeb7224f0ca0dd1741c7b57f92fa3420a40a15b321690_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Registration/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Registration:register_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Registration/register.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Registration\\register.html.twig");
    }
}

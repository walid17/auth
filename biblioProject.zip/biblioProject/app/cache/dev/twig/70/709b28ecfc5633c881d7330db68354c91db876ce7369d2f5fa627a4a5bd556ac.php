<?php

/* @FOSUser/Group/list.html.twig */
class __TwigTemplate_3e629363a3fd9d25a87e682a6fe9e0b6ef6459c5fc8e898c0a42f9a6af24122a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Group/list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_961501164863f5055a4359d68c1ebd4f499b0eb54e97c171f215aefcd1377ac6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_961501164863f5055a4359d68c1ebd4f499b0eb54e97c171f215aefcd1377ac6->enter($__internal_961501164863f5055a4359d68c1ebd4f499b0eb54e97c171f215aefcd1377ac6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_961501164863f5055a4359d68c1ebd4f499b0eb54e97c171f215aefcd1377ac6->leave($__internal_961501164863f5055a4359d68c1ebd4f499b0eb54e97c171f215aefcd1377ac6_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a4be48babe497af705220606134222a5decddb29e2db96f1eaef7bd7c18ea87a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4be48babe497af705220606134222a5decddb29e2db96f1eaef7bd7c18ea87a->enter($__internal_a4be48babe497af705220606134222a5decddb29e2db96f1eaef7bd7c18ea87a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "@FOSUser/Group/list.html.twig", 4)->display($context);
        
        $__internal_a4be48babe497af705220606134222a5decddb29e2db96f1eaef7bd7c18ea87a->leave($__internal_a4be48babe497af705220606134222a5decddb29e2db96f1eaef7bd7c18ea87a_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:list_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/list.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\list.html.twig");
    }
}

<?php

/* :livre:new.html.twig */
class __TwigTemplate_29afaa2e08d30a44324cd5e96de8b6beb0985b521f56fcdd718d03ebe936ddda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":livre:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e151b1231436b390855056650fc270e137b89d831ed6b8273b31c2206acb4e61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e151b1231436b390855056650fc270e137b89d831ed6b8273b31c2206acb4e61->enter($__internal_e151b1231436b390855056650fc270e137b89d831ed6b8273b31c2206acb4e61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":livre:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e151b1231436b390855056650fc270e137b89d831ed6b8273b31c2206acb4e61->leave($__internal_e151b1231436b390855056650fc270e137b89d831ed6b8273b31c2206acb4e61_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_73e4dd9b884d6803b5e9d97843e9417a6f2d8ff2743c4066aaef7e1ea5dd4fd7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73e4dd9b884d6803b5e9d97843e9417a6f2d8ff2743c4066aaef7e1ea5dd4fd7->enter($__internal_73e4dd9b884d6803b5e9d97843e9417a6f2d8ff2743c4066aaef7e1ea5dd4fd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "


    <div class=\"md-card\">
        <div class=\"md-card-content\">


             <h3 class=\"heading_a\">Livre creation</h3>



                    ";
        // line 15
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
                   
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Acteur</label>
                                ";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "acteur", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                             </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Titre</label>
                                ";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "titre", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                             </div>


                          


                             <div class=\"uk-form-row\" style=\" width: 200px; float: left; \">
                                <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                   <div class=\"md-input-wrapper\">
                                      
                                      ";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "imageFile", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                
                                    </div>   
                                 </div>
                             </div>
                        
                             <div class=\"uk-form-row\">
                                 <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                   <div class=\"md-input-wrapper\">
                                      
                                   ";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "imageFil", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                
                                       </div>   
                                 </div>

                            </div>
 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Nombre de page</label>
                                ";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nbrPage", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Download</label>
                                ";
        // line 65
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nbrDownload", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label> </label>
                                ";
        // line 73
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "date", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>
                            

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Category</label>
                                ";
        // line 81
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "idCategory", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>




 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Create\" />
                          </div>  

            
                                ";
        // line 95
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "


        </div>
    </div>



            <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 104
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_index");
        echo "\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>



 
";
        
        $__internal_73e4dd9b884d6803b5e9d97843e9417a6f2d8ff2743c4066aaef7e1ea5dd4fd7->leave($__internal_73e4dd9b884d6803b5e9d97843e9417a6f2d8ff2743c4066aaef7e1ea5dd4fd7_prof);

    }

    public function getTemplateName()
    {
        return ":livre:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  172 => 104,  160 => 95,  143 => 81,  132 => 73,  121 => 65,  110 => 57,  97 => 47,  84 => 37,  69 => 25,  60 => 19,  53 => 15,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}



    <div class=\"md-card\">
        <div class=\"md-card-content\">


             <h3 class=\"heading_a\">Livre creation</h3>



                    {{ form_start(form) }}
                   
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Acteur</label>
                                {{ form_widget(form.acteur,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                             </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Titre</label>
                                {{ form_widget(form.titre,{'attr' : { 'class' : 'md-input' }},{'type':'text'}) }}
                                <span class=\"md-input-bar\"></span></div>
                             </div>


                          


                             <div class=\"uk-form-row\" style=\" width: 200px; float: left; \">
                                <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                   <div class=\"md-input-wrapper\">
                                      
                                      {{ form_widget(form.imageFile,{'attr' : { 'class' : 'md-input' }},{'type':'file'}) }}
                                
                                    </div>   
                                 </div>
                             </div>
                        
                             <div class=\"uk-form-row\">
                                 <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                   <div class=\"md-input-wrapper\">
                                      
                                   {{ form_widget(form.imageFil,{'attr' : { 'class' : 'md-input' }},{'type':'file'}) }}
                                
                                       </div>   
                                 </div>

                            </div>
 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Nombre de page</label>
                                {{ form_widget(form.nbrPage,{'attr' : { 'class' : 'md-input' }},{'type':'number'}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Download</label>
                                {{ form_widget(form.nbrDownload,{'attr' : { 'class' : 'md-input' }},{'type':'number'}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label> </label>
                                {{ form_widget(form.date,{'attr' : { 'class' : 'md-input' }},{'type':'date'}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>
                            

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Category</label>
                                {{ form_widget(form.idCategory,{'attr' : { 'class' : 'md-input' }},{'type':'number'}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>




 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Create\" />
                          </div>  

            
                                {{ form_end(form) }}


        </div>
    </div>



            <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('livre_index') }}\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>



 
{% endblock %}

", ":livre:new.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app/Resources\\views/livre/new.html.twig");
    }
}

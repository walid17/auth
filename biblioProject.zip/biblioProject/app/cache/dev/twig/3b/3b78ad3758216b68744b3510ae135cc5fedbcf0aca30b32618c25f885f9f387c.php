<?php

/* FOSUserBundle:Resetting:checkEmail.html.twig */
class __TwigTemplate_a4165df24afbcb5e7d8294043612db40a1d728b2aa294d38306e4956da2e9663 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7459fdb29a2596f3a1653085b434355a05ad5f3590cb4c8b308c95c8bea7c9b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7459fdb29a2596f3a1653085b434355a05ad5f3590cb4c8b308c95c8bea7c9b1->enter($__internal_7459fdb29a2596f3a1653085b434355a05ad5f3590cb4c8b308c95c8bea7c9b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7459fdb29a2596f3a1653085b434355a05ad5f3590cb4c8b308c95c8bea7c9b1->leave($__internal_7459fdb29a2596f3a1653085b434355a05ad5f3590cb4c8b308c95c8bea7c9b1_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ebb6b9e3ba304a375d6583e1df87518286504490cd44aa625292f181abc74621 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebb6b9e3ba304a375d6583e1df87518286504490cd44aa625292f181abc74621->enter($__internal_ebb6b9e3ba304a375d6583e1df87518286504490cd44aa625292f181abc74621_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.check_email", array("%email%" => (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_ebb6b9e3ba304a375d6583e1df87518286504490cd44aa625292f181abc74621->leave($__internal_ebb6b9e3ba304a375d6583e1df87518286504490cd44aa625292f181abc74621_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
<p>
{{ 'resetting.check_email'|trans({'%email%': email}) }}
</p>
{% endblock %}
", "FOSUserBundle:Resetting:checkEmail.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Resetting/checkEmail.html.twig");
    }
}

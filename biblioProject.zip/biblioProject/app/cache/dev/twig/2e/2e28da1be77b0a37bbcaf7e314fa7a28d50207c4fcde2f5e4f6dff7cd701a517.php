<?php

/* @FOSUser/Group/edit.html.twig */
class __TwigTemplate_76222949669be0f91b0baf3b9310e168a2d3631e66e0bec39b3ba298bcc8dc8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Group/edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e47c7787d4d666dad1db3661f4f1b2ad22503e391651409bf087e71558de1f08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e47c7787d4d666dad1db3661f4f1b2ad22503e391651409bf087e71558de1f08->enter($__internal_e47c7787d4d666dad1db3661f4f1b2ad22503e391651409bf087e71558de1f08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e47c7787d4d666dad1db3661f4f1b2ad22503e391651409bf087e71558de1f08->leave($__internal_e47c7787d4d666dad1db3661f4f1b2ad22503e391651409bf087e71558de1f08_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_63218d5f71ea4095e85ce8b124c8d7fafa9f14a8d7a3b6534107354de66b4ab5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63218d5f71ea4095e85ce8b124c8d7fafa9f14a8d7a3b6534107354de66b4ab5->enter($__internal_63218d5f71ea4095e85ce8b124c8d7fafa9f14a8d7a3b6534107354de66b4ab5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "@FOSUser/Group/edit.html.twig", 4)->display($context);
        
        $__internal_63218d5f71ea4095e85ce8b124c8d7fafa9f14a8d7a3b6534107354de66b4ab5->leave($__internal_63218d5f71ea4095e85ce8b124c8d7fafa9f14a8d7a3b6534107354de66b4ab5_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/edit.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\edit.html.twig");
    }
}

<?php

/* livre/edit.html.twig */
class __TwigTemplate_c3c58b4c3fe46c4889ccb1d37b7dfb1cc0e38dd4122e3a19bd6af8dee80a78e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "livre/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06addcafd0cdb5c6ac83cf41633f4d7076c1fe454a345775efdd4f2687905b12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06addcafd0cdb5c6ac83cf41633f4d7076c1fe454a345775efdd4f2687905b12->enter($__internal_06addcafd0cdb5c6ac83cf41633f4d7076c1fe454a345775efdd4f2687905b12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "livre/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_06addcafd0cdb5c6ac83cf41633f4d7076c1fe454a345775efdd4f2687905b12->leave($__internal_06addcafd0cdb5c6ac83cf41633f4d7076c1fe454a345775efdd4f2687905b12_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_5a581acd957b017061376f0fb83de20e3c623d863a1c4c08eb6a96d3bec90ef0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a581acd957b017061376f0fb83de20e3c623d863a1c4c08eb6a96d3bec90ef0->enter($__internal_5a581acd957b017061376f0fb83de20e3c623d863a1c4c08eb6a96d3bec90ef0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "




    <h1>Modifier Livre</h1>

 

<div class=\"md-card\">
                            <div class=\"md-card-toolbar\">
                                <h3 class=\"md-card-toolbar-heading-text\">
                                    Details
                                </h3>


                                 <a href=\"#\" style=\" float: right; margin: 10px; \">

                                     ";
        // line 22
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                                     <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
                                       <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
                                    </button>

                                    ";
        // line 27
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
                             </a>

                            </div>
                            <div class=\"md-card-content large-padding\">
                                <div class=\"uk-grid uk-grid-divider uk-grid-medium\" data-uk-grid-margin>
                                    <div class=\"uk-width-large-1-1\">
                                     


                    ";
        // line 37
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Name</label>
                                ";
        // line 41
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "acteur", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Description</label>
                                ";
        // line 48
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "titre", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                            <div class=\"uk-grid\" data-uk-grid-margin=\"\" style=\" margin-top: 20px; \"> 
                              <div class=\"uk-width-medium-1-5\">
                              <img src=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/template/image/pdf.png"), "html", null, true);
        echo "\" style=\"width: 80px;\">
                              </div>
                              <div class=\"uk-width-medium-1-2\">

                                <div class=\"uk-form-row\">
                                    <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                       <div class=\"md-input-wrapper\">
                                     
                                        ";
        // line 64
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "imageFil", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                        </div>   
                                     </div>
                                 </div>
                             </div>
                             </div>


                              <div class=\"uk-grid\" data-uk-grid-margin=\"\" style=\" margin-top: 20px; \"> 
                              <div class=\"uk-width-medium-1-5\">
                                       <img src=\"";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/images/products/" . $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "imageName", array()))), "html", null, true);
        echo "\" style=\"width: 80px;\">
                              </div>
                              <div class=\"uk-width-medium-1-2\">

                                <div class=\"uk-form-row\">
                                    <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                       <div class=\"md-input-wrapper\">
                                     
                                        ";
        // line 82
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "imageFile", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                        </div>   
                                     </div>
                                 </div>
                             </div>
                             </div>
 

 


                                      </div>
                         </div>


 


                              <div class=\"uk-form-row\" style=\"margin-top: 15px\">
                                <div class=\"md-input-wrapper md-input-filled\">
                                    <label>Nombre de Page:</label>
                                    ";
        // line 103
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "nbrPage", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                    <span class=\"md-input-bar\"></span>

                                </div>
                              </div>


                              <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>>Nombre de Download:</label>
                                ";
        // line 112
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "nbrDownload", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label> </label>
                                ";
        // line 120
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "date", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>







                              <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\">
                                    <label>Type Category</label>
                                    ";
        // line 134
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), "idCategory", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                    <span class=\"md-input-bar\"></span>
                                </div>
                              </div>


 



 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Modifier\" />
                          </div>  

             ";
        // line 149
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "


                                    </div>
                                   
                                </div>
                            </div>
                        </div>

   

 

         <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 163
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_index");
        echo "\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>


 


";
        
        $__internal_5a581acd957b017061376f0fb83de20e3c623d863a1c4c08eb6a96d3bec90ef0->leave($__internal_5a581acd957b017061376f0fb83de20e3c623d863a1c4c08eb6a96d3bec90ef0_prof);

    }

    public function getTemplateName()
    {
        return "livre/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  243 => 163,  226 => 149,  208 => 134,  191 => 120,  180 => 112,  168 => 103,  144 => 82,  133 => 74,  120 => 64,  109 => 56,  98 => 48,  88 => 41,  81 => 37,  68 => 27,  60 => 22,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}





    <h1>Modifier Livre</h1>

 

<div class=\"md-card\">
                            <div class=\"md-card-toolbar\">
                                <h3 class=\"md-card-toolbar-heading-text\">
                                    Details
                                </h3>


                                 <a href=\"#\" style=\" float: right; margin: 10px; \">

                                     {{ form_start(delete_form) }}
                                     <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
                                       <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
                                    </button>

                                    {{ form_end(delete_form) }}
                             </a>

                            </div>
                            <div class=\"md-card-content large-padding\">
                                <div class=\"uk-grid uk-grid-divider uk-grid-medium\" data-uk-grid-margin>
                                    <div class=\"uk-width-large-1-1\">
                                     


                    {{ form_start(edit_form) }}
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Name</label>
                                {{ form_widget(edit_form.acteur,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>Description</label>
                                {{ form_widget(edit_form.titre,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                            <div class=\"uk-grid\" data-uk-grid-margin=\"\" style=\" margin-top: 20px; \"> 
                              <div class=\"uk-width-medium-1-5\">
                              <img src=\"{{ asset('/template/image/pdf.png') }}\" style=\"width: 80px;\">
                              </div>
                              <div class=\"uk-width-medium-1-2\">

                                <div class=\"uk-form-row\">
                                    <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                       <div class=\"md-input-wrapper\">
                                     
                                        {{ form_widget(edit_form.imageFil,{'attr' : { 'class' : 'md-input' }}) }}
                                        </div>   
                                     </div>
                                 </div>
                             </div>
                             </div>


                              <div class=\"uk-grid\" data-uk-grid-margin=\"\" style=\" margin-top: 20px; \"> 
                              <div class=\"uk-width-medium-1-5\">
                                       <img src=\"{{asset('/images/products/'~livre.imageName)}}\" style=\"width: 80px;\">
                              </div>
                              <div class=\"uk-width-medium-1-2\">

                                <div class=\"uk-form-row\">
                                    <div class=\"uk-form-file md-btn md-btn-primary\" style=\" width: 176px; \">
                                       <div class=\"md-input-wrapper\">
                                     
                                        {{ form_widget(edit_form.imageFile,{'attr' : { 'class' : 'md-input' }}) }}
                                        </div>   
                                     </div>
                                 </div>
                             </div>
                             </div>
 

 


                                      </div>
                         </div>


 


                              <div class=\"uk-form-row\" style=\"margin-top: 15px\">
                                <div class=\"md-input-wrapper md-input-filled\">
                                    <label>Nombre de Page:</label>
                                    {{ form_widget(edit_form.nbrPage,{'attr' : { 'class' : 'md-input' }}) }}
                                    <span class=\"md-input-bar\"></span>

                                </div>
                              </div>


                              <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\"><label>>Nombre de Download:</label>
                                {{ form_widget(edit_form.nbrDownload,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label> </label>
                                {{ form_widget(edit_form.date,{'attr' : { 'class' : 'md-input' }},{'type':'date'}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>







                              <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper md-input-filled\">
                                    <label>Type Category</label>
                                    {{ form_widget(edit_form.idCategory,{'attr' : { 'class' : 'md-input' }}) }}
                                    <span class=\"md-input-bar\"></span>
                                </div>
                              </div>


 



 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Modifier\" />
                          </div>  

             {{ form_end(edit_form) }}


                                    </div>
                                   
                                </div>
                            </div>
                        </div>

   

 

         <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('livre_index') }}\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>


 


{% endblock %}
", "livre/edit.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app\\Resources\\views\\livre\\edit.html.twig");
    }
}

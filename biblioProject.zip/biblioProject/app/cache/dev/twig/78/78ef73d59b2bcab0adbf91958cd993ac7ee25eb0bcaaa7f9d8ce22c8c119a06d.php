<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_5c1e13afdec6f77fcad757f07827dbda2a586b19a687b2e7fc8dcc7010745f01 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_013c8dce0d298b75a29919123676ef28dd188cb77b6d345a7cb7b9ca6c02d537 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_013c8dce0d298b75a29919123676ef28dd188cb77b6d345a7cb7b9ca6c02d537->enter($__internal_013c8dce0d298b75a29919123676ef28dd188cb77b6d345a7cb7b9ca6c02d537_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_013c8dce0d298b75a29919123676ef28dd188cb77b6d345a7cb7b9ca6c02d537->leave($__internal_013c8dce0d298b75a29919123676ef28dd188cb77b6d345a7cb7b9ca6c02d537_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_36e4f3f03e28c8eb4c76300c8f4d7d306b19684c3836d9de4f439eda374b09f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36e4f3f03e28c8eb4c76300c8f4d7d306b19684c3836d9de4f439eda374b09f8->enter($__internal_36e4f3f03e28c8eb4c76300c8f4d7d306b19684c3836d9de4f439eda374b09f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_36e4f3f03e28c8eb4c76300c8f4d7d306b19684c3836d9de4f439eda374b09f8->leave($__internal_36e4f3f03e28c8eb4c76300c8f4d7d306b19684c3836d9de4f439eda374b09f8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:new_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:new.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Group/new.html.twig");
    }
}

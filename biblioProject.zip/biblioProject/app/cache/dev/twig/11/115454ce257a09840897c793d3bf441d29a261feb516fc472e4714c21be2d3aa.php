<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_91b5b53e3368b47d9219b224b2e5469383cb2768776fde164dd863f505d78bf1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f3ca576d411f1f6f8b87a9f2c92941f929fc702871577085a4e03f74f51c024b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3ca576d411f1f6f8b87a9f2c92941f929fc702871577085a4e03f74f51c024b->enter($__internal_f3ca576d411f1f6f8b87a9f2c92941f929fc702871577085a4e03f74f51c024b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f3ca576d411f1f6f8b87a9f2c92941f929fc702871577085a4e03f74f51c024b->leave($__internal_f3ca576d411f1f6f8b87a9f2c92941f929fc702871577085a4e03f74f51c024b_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_15063aeddb7723f65d8333a05d2017d016fa205253d3275a532d32fa14022fcb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15063aeddb7723f65d8333a05d2017d016fa205253d3275a532d32fa14022fcb->enter($__internal_15063aeddb7723f65d8333a05d2017d016fa205253d3275a532d32fa14022fcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_15063aeddb7723f65d8333a05d2017d016fa205253d3275a532d32fa14022fcb->leave($__internal_15063aeddb7723f65d8333a05d2017d016fa205253d3275a532d32fa14022fcb_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Registration:register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Registration\\register.html.twig");
    }
}

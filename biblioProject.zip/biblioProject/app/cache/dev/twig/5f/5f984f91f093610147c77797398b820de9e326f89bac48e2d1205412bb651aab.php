<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_9d9304953e34b1ab0505091fb7c3ed0eb234ce90bd20e6dbc50d7f6b1d6f800c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2864020d1e1e873daccd070c7cc8ffba70eb5ac70ede92e93e9c80ee55a3850e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2864020d1e1e873daccd070c7cc8ffba70eb5ac70ede92e93e9c80ee55a3850e->enter($__internal_2864020d1e1e873daccd070c7cc8ffba70eb5ac70ede92e93e9c80ee55a3850e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_2864020d1e1e873daccd070c7cc8ffba70eb5ac70ede92e93e9c80ee55a3850e->leave($__internal_2864020d1e1e873daccd070c7cc8ffba70eb5ac70ede92e93e9c80ee55a3850e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}

<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_8231e45dec954485ff81e094c4731e47ec74f164bb03ff68d774078e1b8eab24 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf0953a97ff06ac4573741e6b756c8feb019468cb41ed349ee20324f79e6afb1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf0953a97ff06ac4573741e6b756c8feb019468cb41ed349ee20324f79e6afb1->enter($__internal_bf0953a97ff06ac4573741e6b756c8feb019468cb41ed349ee20324f79e6afb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_bf0953a97ff06ac4573741e6b756c8feb019468cb41ed349ee20324f79e6afb1->leave($__internal_bf0953a97ff06ac4573741e6b756c8feb019468cb41ed349ee20324f79e6afb1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}

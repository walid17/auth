<?php

/* @FOSUser/Security/login.html.twig */
class __TwigTemplate_073b0d0a719a75fd1df28ff97d61e814f25cc8253d6c8504a59cfa032a49e54d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Security/login.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f829a1f021b920311291546c68a130c75f761dd2aa87cff6f02ec0038ff55b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f829a1f021b920311291546c68a130c75f761dd2aa87cff6f02ec0038ff55b7->enter($__internal_8f829a1f021b920311291546c68a130c75f761dd2aa87cff6f02ec0038ff55b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8f829a1f021b920311291546c68a130c75f761dd2aa87cff6f02ec0038ff55b7->leave($__internal_8f829a1f021b920311291546c68a130c75f761dd2aa87cff6f02ec0038ff55b7_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4c31182fb4710545b7e1f4716bd76e1c43772bc6999c65b0db30488e842b1b9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c31182fb4710545b7e1f4716bd76e1c43772bc6999c65b0db30488e842b1b9e->enter($__internal_4c31182fb4710545b7e1f4716bd76e1c43772bc6999c65b0db30488e842b1b9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "


<div class=\"login_page_wrapper\">
        <div class=\"md-card\" id=\"login_card\">
            <div class=\"md-card-content large-padding\" id=\"login_form\">
                <div class=\"login_heading\">
                   <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/logo.png"), "html", null, true);
        echo "\" alt=\"\" height=\"150\" width=\"150\" />
                </div>




             
\t\t\t\t<form action=\"";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
\t\t\t\t  <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\" />

                    <div class=\"uk-form-row\">
                        <label for=\"login_username\">";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.username", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                         <input  class=\"md-input\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" />
                    </div>

                    <div class=\"uk-form-row\">
                        <label for=\"login_username\">";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.password", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                         <input type=\"password\"  class=\"md-input\"  id=\"password\" name=\"_password\" required=\"required\" />
                    </div>



   \t\t\t\t\t<div class=\"uk-margin-top\">
                        <span class=\"icheck-inline\">
                            <input type=\"checkbox\" name=\"login_page_stay_signed\" id=\"remember_me\" name=\"_remember_me\" data-md-icheck />
                            <label for=\"remember_me\" class=\"inline-label\">";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.remember_me", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                        </span>
                    </div>

                    <div class=\"uk-margin-medium-top\">
 
                        <input type=\"submit\" id=\"_submit\" onclick=\"fnshowload()\" name=\"_submit\"  class=\"md-btn md-btn-primary md-btn-block md-btn-large\" value=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\">
                    </div>

                </form>



            </div>
            
        </div>
        <div class=\"uk-margin-top\">
            ";
        // line 55
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 56
            echo "\t\t\t    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
\t\t\t";
        }
        // line 58
        echo "        </div>
    </div>
 




<!--
<form action=\"";
        // line 66
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 67
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\" />

    <label for=\"username\">";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.username", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
    <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 70
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" />

    <label for=\"password\">";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.password", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
    <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" />

    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
    <label for=\"remember_me\">";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.remember_me", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>

    <input type=\"submit\" id=\"_submit\" name=\"_submit\" value=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\" />
</form>

-->


";
        
        $__internal_4c31182fb4710545b7e1f4716bd76e1c43772bc6999c65b0db30488e842b1b9e->leave($__internal_4c31182fb4710545b7e1f4716bd76e1c43772bc6999c65b0db30488e842b1b9e_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  163 => 78,  158 => 76,  151 => 72,  146 => 70,  142 => 69,  137 => 67,  133 => 66,  123 => 58,  117 => 56,  115 => 55,  101 => 44,  92 => 38,  80 => 29,  73 => 25,  69 => 24,  63 => 21,  59 => 20,  49 => 13,  40 => 6,  34 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}



<div class=\"login_page_wrapper\">
        <div class=\"md-card\" id=\"login_card\">
            <div class=\"md-card-content large-padding\" id=\"login_form\">
                <div class=\"login_heading\">
                   <img src=\"{{ asset('template/assets/img/logo.png') }}\" alt=\"\" height=\"150\" width=\"150\" />
                </div>




             
\t\t\t\t<form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
\t\t\t\t  <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />

                    <div class=\"uk-form-row\">
                        <label for=\"login_username\">{{ 'security.login.username'|trans }}</label>
                         <input  class=\"md-input\" type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" />
                    </div>

                    <div class=\"uk-form-row\">
                        <label for=\"login_username\">{{ 'security.login.password'|trans }}</label>
                         <input type=\"password\"  class=\"md-input\"  id=\"password\" name=\"_password\" required=\"required\" />
                    </div>



   \t\t\t\t\t<div class=\"uk-margin-top\">
                        <span class=\"icheck-inline\">
                            <input type=\"checkbox\" name=\"login_page_stay_signed\" id=\"remember_me\" name=\"_remember_me\" data-md-icheck />
                            <label for=\"remember_me\" class=\"inline-label\">{{ 'security.login.remember_me'|trans }}</label>
                        </span>
                    </div>

                    <div class=\"uk-margin-medium-top\">
 
                        <input type=\"submit\" id=\"_submit\" onclick=\"fnshowload()\" name=\"_submit\"  class=\"md-btn md-btn-primary md-btn-block md-btn-large\" value=\"{{ 'security.login.submit'|trans }}\">
                    </div>

                </form>



            </div>
            
        </div>
        <div class=\"uk-margin-top\">
            {% if error %}
\t\t\t    <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
\t\t\t{% endif %}
        </div>
    </div>
 




<!--
<form action=\"{{ path(\"fos_user_security_check\") }}\" method=\"post\">
    <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token }}\" />

    <label for=\"username\">{{ 'security.login.username'|trans }}</label>
    <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" required=\"required\" />

    <label for=\"password\">{{ 'security.login.password'|trans }}</label>
    <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" />

    <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
    <label for=\"remember_me\">{{ 'security.login.remember_me'|trans }}</label>

    <input type=\"submit\" id=\"_submit\" name=\"_submit\" value=\"{{ 'security.login.submit'|trans }}\" />
</form>

-->


{% endblock fos_user_content %}
", "@FOSUser/Security/login.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Security\\login.html.twig");
    }
}

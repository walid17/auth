<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_7139b4202a8880339d7ed38a45e93c21d24f3ec33326d7a1facc8e967da087d5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1cd9973998d80b16b385a929e0e810d758d08f9cb07403cac2fafe20bfaa28db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1cd9973998d80b16b385a929e0e810d758d08f9cb07403cac2fafe20bfaa28db->enter($__internal_1cd9973998d80b16b385a929e0e810d758d08f9cb07403cac2fafe20bfaa28db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_1cd9973998d80b16b385a929e0e810d758d08f9cb07403cac2fafe20bfaa28db->leave($__internal_1cd9973998d80b16b385a929e0e810d758d08f9cb07403cac2fafe20bfaa28db_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\attributes.html.php");
    }
}

<?php

/* AcmeBiblioBundle:Default:index.html.twig */
class __TwigTemplate_dadf1f895d4158ed79e48515894463e378205683305f1c1e5c5d523630a3c524 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_019f11a71f59977f378f927589f69f79640974ca9c70b53cae9762df95f69e2e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_019f11a71f59977f378f927589f69f79640974ca9c70b53cae9762df95f69e2e->enter($__internal_019f11a71f59977f378f927589f69f79640974ca9c70b53cae9762df95f69e2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AcmeBiblioBundle:Default:index.html.twig"));

        // line 1
        echo "

        <!DOCTYPE html>
<html>
     <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "        <link rel=\"icon\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
  
    <body class=\"login_page\" style=\"margin: 0 auto;padding-left:2%;\">






<div id=\"page_content\">
        <div id=\"page_content_inner \">


\t<div style=\" margin: 0 auto;display: block;width: 190px;margin-top: 40px; \">
\t\t<img src=\"/template/assets/img/logo.png\" alt=\"\" height=\"130\" width=\"130\" style=\" margin: 14px; \" class=\"\">
\t</div>

\t\t\t<div class=\"md-card  hierarchical_show\" style=\"width: 98%; \" >
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-star \" style=\" color: #F44336; \"></i> Top 5 Download
                    </h3>
                     
                </div>
            </div>
 


        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">



";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")));
        foreach ($context['_seq'] as $context["_key"] => $context["l"]) {
            // line 52
            echo "           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\" style=\" width: 22%;\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"/images/products/";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "imageName", array()), "html", null, true);
            echo "\"  style=\" width: 90%; \"/>
                            </div>

                           
<script>
function newDoc() {
    window.location.assign(\"";
            // line 70
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_update", array("id" => $this->getAttribute($context["l"], "id", array()))), "html", null, true);
            echo "\");
}
</script>


                        <div class=\"md-card-overlay-content\" >
                        \t <a class=\"md-fab md-fab-small md-fab-accent\"  href=\"/images/pdfs/";
            // line 76
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "imageNam", array()), "html", null, true);
            echo "\"
                     onclick=\"newDoc()\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\" download>
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a>
                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   ";
            // line 84
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "titre", array()), "html", null, true);
            echo "
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  ";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "acteur", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 114
            if ($this->getAttribute($context["l"], "date", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["l"], "date", array()), "Y-m-d"), "html", null, true);
            }
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrDownload", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 134
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrPage", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['l'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 152
        echo "
                 



            </div>


\t\t<div class=\"md-card  hierarchical_show\" style=\"margin-top: 20px; width: 98%; \">
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-book \" style=\" color: #F44336; \"></i> Livre Recent
                    </h3>
                     
                </div>
            </div>





        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">



";
        // line 178
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")));
        foreach ($context['_seq'] as $context["_key"] => $context["l"]) {
            // line 179
            echo "           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"/images/products/";
            // line 191
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "imageName", array()), "html", null, true);
            echo "\"  style=\" width: 90%; \"/>
                            </div>

                           



                        <div class=\"md-card-overlay-content\" >
                        \t
                        \t <a class=\"md-fab md-fab-small md-fab-accent\" href=\"/images/pdfs/";
            // line 200
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "imageNam", array()), "html", null, true);
            echo "\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\">
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a>


                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   ";
            // line 209
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "titre", array()), "html", null, true);
            echo "
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  ";
            // line 223
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "acteur", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 239
            if ($this->getAttribute($context["l"], "date", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["l"], "date", array()), "Y-m-d"), "html", null, true);
            }
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 249
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrDownload", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 259
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrPage", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['l'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 277
        echo "
                 



            </div>




   \t </div>


    </div>

 

<style type=\"text/css\">
    

    #acme_bibliobundle_livre_date_year{
 width: 10%;
 float: left;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


   #acme_bibliobundle_livre_date_month {
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


    #acme_bibliobundle_livre_date_day{
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }

    .uk-grid-width-large-1-4>* {
    width: 24.5%;
}


</style>





    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
 

        ";
        // line 378
        $this->displayBlock('javascripts', $context, $blocks);
        // line 391
        echo "    </body>
</html>
";
        
        $__internal_019f11a71f59977f378f927589f69f79640974ca9c70b53cae9762df95f69e2e->leave($__internal_019f11a71f59977f378f927589f69f79640974ca9c70b53cae9762df95f69e2e_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_7439d00b16187df843c72338142b3477c9493b11a2039a0c618d8e3de06810cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7439d00b16187df843c72338142b3477c9493b11a2039a0c618d8e3de06810cf->enter($__internal_7439d00b16187df843c72338142b3477c9493b11a2039a0c618d8e3de06810cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_7439d00b16187df843c72338142b3477c9493b11a2039a0c618d8e3de06810cf->leave($__internal_7439d00b16187df843c72338142b3477c9493b11a2039a0c618d8e3de06810cf_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_cdd6622fa59c99f2ef733da513e475a6bbc9e52892eae411a0f2bfa4a0c0be67 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cdd6622fa59c99f2ef733da513e475a6bbc9e52892eae411a0f2bfa4a0c0be67->enter($__internal_cdd6622fa59c99f2ef733da513e475a6bbc9e52892eae411a0f2bfa4a0c0be67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "

 

     <link  rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/bower_components/uikit/css/uikit.almost-flat.min.css"), "html", null, true);
        echo "\" />
     <link  rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/css/main.min.css"), "html", null, true);
        echo "\" />
     <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/icons/flags/flags.min.css"), "html", null, true);
        echo "\" /> 
        ";
        
        $__internal_cdd6622fa59c99f2ef733da513e475a6bbc9e52892eae411a0f2bfa4a0c0be67->leave($__internal_cdd6622fa59c99f2ef733da513e475a6bbc9e52892eae411a0f2bfa4a0c0be67_prof);

    }

    // line 378
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_320f244f2ef2ff3910d8279371abde286363ed2e0e161e9820216b1825a719f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_320f244f2ef2ff3910d8279371abde286363ed2e0e161e9820216b1825a719f8->enter($__internal_320f244f2ef2ff3910d8279371abde286363ed2e0e161e9820216b1825a719f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 379
        echo "   <script   type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/bower_components/moment/min/moment.min.js"), "html", null, true);
        echo "\" ></script>
  <script  type=\"text/javascript\" src=\"";
        // line 380
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/common.min.js"), "html", null, true);
        echo "\"></script>
 <script   type=\"text/javascript\" src=\"";
        // line 381
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/uikit_custom.min.js"), "html", null, true);
        echo "\" ></script>
 <script   type=\"text/javascript\" src=\"";
        // line 382
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/altair_admin_common.min.js"), "html", null, true);
        echo "\" ></script>
    <!-- enable hires images -->
    <script>
        \$(function() {
            altair_helpers.retina_images();
        });
    </script>

        ";
        
        $__internal_320f244f2ef2ff3910d8279371abde286363ed2e0e161e9820216b1825a719f8->leave($__internal_320f244f2ef2ff3910d8279371abde286363ed2e0e161e9820216b1825a719f8_prof);

    }

    public function getTemplateName()
    {
        return "AcmeBiblioBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  544 => 382,  540 => 381,  536 => 380,  531 => 379,  525 => 378,  516 => 15,  512 => 14,  508 => 13,  502 => 9,  496 => 8,  484 => 7,  475 => 391,  473 => 378,  370 => 277,  346 => 259,  333 => 249,  318 => 239,  299 => 223,  282 => 209,  270 => 200,  258 => 191,  244 => 179,  240 => 178,  212 => 152,  188 => 134,  175 => 124,  160 => 114,  141 => 98,  124 => 84,  113 => 76,  104 => 70,  95 => 64,  81 => 52,  77 => 51,  39 => 17,  37 => 8,  33 => 7,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

        <!DOCTYPE html>
<html>
     <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}


 

     <link  rel=\"stylesheet\" href=\"{{ asset('template/bower_components/uikit/css/uikit.almost-flat.min.css') }}\" />
     <link  rel=\"stylesheet\" href=\"{{ asset('template/assets/css/main.min.css') }}\" />
     <link rel=\"stylesheet\" href=\"{{ asset('template/assets/icons/flags/flags.min.css') }}\" /> 
        {% endblock %}
        <link rel=\"icon\" type=\"text/css\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
  
    <body class=\"login_page\" style=\"margin: 0 auto;padding-left:2%;\">






<div id=\"page_content\">
        <div id=\"page_content_inner \">


\t<div style=\" margin: 0 auto;display: block;width: 190px;margin-top: 40px; \">
\t\t<img src=\"/template/assets/img/logo.png\" alt=\"\" height=\"130\" width=\"130\" style=\" margin: 14px; \" class=\"\">
\t</div>

\t\t\t<div class=\"md-card  hierarchical_show\" style=\"width: 98%; \" >
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-star \" style=\" color: #F44336; \"></i> Top 5 Download
                    </h3>
                     
                </div>
            </div>
 


        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">



{% for l in livre %}
           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\" style=\" width: 22%;\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"/images/products/{{ l.imageName }}\"  style=\" width: 90%; \"/>
                            </div>

                           
<script>
function newDoc() {
    window.location.assign(\"{{ path('livre_update', { 'id': l.id }) }}\");
}
</script>


                        <div class=\"md-card-overlay-content\" >
                        \t <a class=\"md-fab md-fab-small md-fab-accent\"  href=\"/images/pdfs/{{ l.imageNam }}\"
                     onclick=\"newDoc()\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\" download>
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a>
                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   {{ l.titre }}
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  {{ l.acteur }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{% if l.date %}{{ l.date|date('Y-m-d') }}{% endif %}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrDownload }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrPage }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        {% endfor %}

                 



            </div>


\t\t<div class=\"md-card  hierarchical_show\" style=\"margin-top: 20px; width: 98%; \">
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-book \" style=\" color: #F44336; \"></i> Livre Recent
                    </h3>
                     
                </div>
            </div>





        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">



{% for l in livre %}
           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"/images/products/{{ l.imageName }}\"  style=\" width: 90%; \"/>
                            </div>

                           



                        <div class=\"md-card-overlay-content\" >
                        \t
                        \t <a class=\"md-fab md-fab-small md-fab-accent\" href=\"/images/pdfs/{{ l.imageNam }}\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\">
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a>


                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   {{ l.titre }}
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  {{ l.acteur }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{% if l.date %}{{ l.date|date('Y-m-d') }}{% endif %}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrDownload }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrPage }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        {% endfor %}

                 



            </div>




   \t </div>


    </div>

 

<style type=\"text/css\">
    

    #acme_bibliobundle_livre_date_year{
 width: 10%;
 float: left;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


   #acme_bibliobundle_livre_date_month {
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


    #acme_bibliobundle_livre_date_day{
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }

    .uk-grid-width-large-1-4>* {
    width: 24.5%;
}


</style>





    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
 

        {% block javascripts %}
   <script   type=\"text/javascript\" src=\"{{ asset('template/bower_components/moment/min/moment.min.js') }}\" ></script>
  <script  type=\"text/javascript\" src=\"{{ asset('template/assets/js/common.min.js') }}\"></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/uikit_custom.min.js') }}\" ></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/altair_admin_common.min.js') }}\" ></script>
    <!-- enable hires images -->
    <script>
        \$(function() {
            altair_helpers.retina_images();
        });
    </script>

        {% endblock %}
    </body>
</html>
", "AcmeBiblioBundle:Default:index.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\src\\Acme\\BiblioBundle/Resources/views/Default/index.html.twig");
    }
}

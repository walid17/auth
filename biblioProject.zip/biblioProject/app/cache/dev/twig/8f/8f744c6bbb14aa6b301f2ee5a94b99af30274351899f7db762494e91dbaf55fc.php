<?php

/* FOSUserBundle:ChangePassword:changePassword.html.twig */
class __TwigTemplate_88fb854d3b18686cedfd94c1cfdcdc9972719b621adf9fcc123948cc5221b98c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_27078f029bd2e2d2b671803673493160bb8922a93fecf3d2e91935246fb7d804 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27078f029bd2e2d2b671803673493160bb8922a93fecf3d2e91935246fb7d804->enter($__internal_27078f029bd2e2d2b671803673493160bb8922a93fecf3d2e91935246fb7d804_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_27078f029bd2e2d2b671803673493160bb8922a93fecf3d2e91935246fb7d804->leave($__internal_27078f029bd2e2d2b671803673493160bb8922a93fecf3d2e91935246fb7d804_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_54ab43a221e20bc27e7654faecc29d49bc801219449d4417770ca7b08af60840 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54ab43a221e20bc27e7654faecc29d49bc801219449d4417770ca7b08af60840->enter($__internal_54ab43a221e20bc27e7654faecc29d49bc801219449d4417770ca7b08af60840_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 4)->display($context);
        
        $__internal_54ab43a221e20bc27e7654faecc29d49bc801219449d4417770ca7b08af60840->leave($__internal_54ab43a221e20bc27e7654faecc29d49bc801219449d4417770ca7b08af60840_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:ChangePassword:changePassword_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:ChangePassword:changePassword.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle/Resources/views/ChangePassword/changePassword.html.twig");
    }
}

<?php

/* @FOSUser/Resetting/reset.html.twig */
class __TwigTemplate_c5bdfc48659b681705a48dad6d198e2edc0d099b326593030c03589125ecdc5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Resetting/reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca8b0a4cd12dd1da96cb3fdd441c143aac70776b8e62d7a6652b1d4cdaf20976 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca8b0a4cd12dd1da96cb3fdd441c143aac70776b8e62d7a6652b1d4cdaf20976->enter($__internal_ca8b0a4cd12dd1da96cb3fdd441c143aac70776b8e62d7a6652b1d4cdaf20976_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Resetting/reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ca8b0a4cd12dd1da96cb3fdd441c143aac70776b8e62d7a6652b1d4cdaf20976->leave($__internal_ca8b0a4cd12dd1da96cb3fdd441c143aac70776b8e62d7a6652b1d4cdaf20976_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c63e316d7fbdf59e363ef7f57b44bab23f91a97fb3826d94773d5ad74b80dd66 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c63e316d7fbdf59e363ef7f57b44bab23f91a97fb3826d94773d5ad74b80dd66->enter($__internal_c63e316d7fbdf59e363ef7f57b44bab23f91a97fb3826d94773d5ad74b80dd66_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:reset_content.html.twig", "@FOSUser/Resetting/reset.html.twig", 4)->display($context);
        
        $__internal_c63e316d7fbdf59e363ef7f57b44bab23f91a97fb3826d94773d5ad74b80dd66->leave($__internal_c63e316d7fbdf59e363ef7f57b44bab23f91a97fb3826d94773d5ad74b80dd66_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Resetting/reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Resetting:reset_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Resetting/reset.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Resetting\\reset.html.twig");
    }
}

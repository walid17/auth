<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_83f0d0c88dfaa45ae714afe82be0efb4d4b64a198664aa766c391e1e823a0951 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c798e9912eb6c32e1ed887cb63bf56dd616d380670cd59ee7a69ee2295a1a52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c798e9912eb6c32e1ed887cb63bf56dd616d380670cd59ee7a69ee2295a1a52->enter($__internal_8c798e9912eb6c32e1ed887cb63bf56dd616d380670cd59ee7a69ee2295a1a52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8c798e9912eb6c32e1ed887cb63bf56dd616d380670cd59ee7a69ee2295a1a52->leave($__internal_8c798e9912eb6c32e1ed887cb63bf56dd616d380670cd59ee7a69ee2295a1a52_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c24752e19790f16077908a8aac2cce12b18f1d63a385b30139342ee4a6b498fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c24752e19790f16077908a8aac2cce12b18f1d63a385b30139342ee4a6b498fe->enter($__internal_c24752e19790f16077908a8aac2cce12b18f1d63a385b30139342ee4a6b498fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_c24752e19790f16077908a8aac2cce12b18f1d63a385b30139342ee4a6b498fe->leave($__internal_c24752e19790f16077908a8aac2cce12b18f1d63a385b30139342ee4a6b498fe_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_381d3cb6f9e0690b18af64a2085c3cc1487c49808a1253993a6cbcef8f1d1e5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_381d3cb6f9e0690b18af64a2085c3cc1487c49808a1253993a6cbcef8f1d1e5c->enter($__internal_381d3cb6f9e0690b18af64a2085c3cc1487c49808a1253993a6cbcef8f1d1e5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_381d3cb6f9e0690b18af64a2085c3cc1487c49808a1253993a6cbcef8f1d1e5c->leave($__internal_381d3cb6f9e0690b18af64a2085c3cc1487c49808a1253993a6cbcef8f1d1e5c_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e67409b2ead27d29274cd9648166683757652dc9f72573dd64f6ddf533e6c29e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e67409b2ead27d29274cd9648166683757652dc9f72573dd64f6ddf533e6c29e->enter($__internal_e67409b2ead27d29274cd9648166683757652dc9f72573dd64f6ddf533e6c29e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e67409b2ead27d29274cd9648166683757652dc9f72573dd64f6ddf533e6c29e->leave($__internal_e67409b2ead27d29274cd9648166683757652dc9f72573dd64f6ddf533e6c29e_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}

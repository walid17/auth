<?php

/* category/show.html.twig */
class __TwigTemplate_53b3dac492cc4818b0556c067329896c1028f8bdec3beccfd0cf70ce4ca19697 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5db8e16cc9a7fe345b6e69619d496e9d34235869cccc51ba7bcd8ba2760c540e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5db8e16cc9a7fe345b6e69619d496e9d34235869cccc51ba7bcd8ba2760c540e->enter($__internal_5db8e16cc9a7fe345b6e69619d496e9d34235869cccc51ba7bcd8ba2760c540e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5db8e16cc9a7fe345b6e69619d496e9d34235869cccc51ba7bcd8ba2760c540e->leave($__internal_5db8e16cc9a7fe345b6e69619d496e9d34235869cccc51ba7bcd8ba2760c540e_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_162aa28a8b3295812ae001de62b24f74501f2cea2bb44874d68a2779db345e6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_162aa28a8b3295812ae001de62b24f74501f2cea2bb44874d68a2779db345e6d->enter($__internal_162aa28a8b3295812ae001de62b24f74501f2cea2bb44874d68a2779db345e6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "



<div class=\"md-card\">
    <div class=\"md-card-toolbar\">
        <h3 class=\"md-card-toolbar-heading-text\">
            Category
        </h3>

        <a href=\"#\" style=\" float: right; margin: 10px; \">

             ";
        // line 16
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
             <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
               <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
            </button>

            ";
        // line 21
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "

            
        </a>

        <a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_edit", array("id" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "id", array()))), "html", null, true);
        echo "\" style=\" float: right; margin: 12px;\"><i class=\"material-icons\" style=\" font-size: 22px; \">border_color</i></a>
    </div>
    <div class=\"md-card-content\">
        <ul class=\"md-list\">
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Id</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "id", array()), "html", null, true);
        echo "</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Name</span>
                    <span class=\"md-list-heading uk-text-large\">";
        // line 39
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "name", array()), "html", null, true);
        echo "</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Description</span>
                    <span class=\"md-list-heading uk-text-large\">";
        // line 45
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "description", array()), "html", null, true);
        echo "</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Type</span>
                    <span class=\"md-list-heading uk-text-large\">";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "type", array()), "html", null, true);
        echo "</span>
                </div>
            </li>
        </ul>
    </div>
</div>
 

      <div class=\"md-fab-wrapper\">
            <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">
            <i class=\"material-icons\">list</i>
            </a>
         
        </div>


";
        
        $__internal_162aa28a8b3295812ae001de62b24f74501f2cea2bb44874d68a2779db345e6d->leave($__internal_162aa28a8b3295812ae001de62b24f74501f2cea2bb44874d68a2779db345e6d_prof);

    }

    public function getTemplateName()
    {
        return "category/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 60,  107 => 51,  98 => 45,  89 => 39,  80 => 33,  70 => 26,  62 => 21,  54 => 16,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}




<div class=\"md-card\">
    <div class=\"md-card-toolbar\">
        <h3 class=\"md-card-toolbar-heading-text\">
            Category
        </h3>

        <a href=\"#\" style=\" float: right; margin: 10px; \">

             {{ form_start(delete_form) }}
             <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
               <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
            </button>

            {{ form_end(delete_form) }}

            
        </a>

        <a href=\"{{ path('category_edit', { 'id': category.id }) }}\" style=\" float: right; margin: 12px;\"><i class=\"material-icons\" style=\" font-size: 22px; \">border_color</i></a>
    </div>
    <div class=\"md-card-content\">
        <ul class=\"md-list\">
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Id</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">{{ category.id }}</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Name</span>
                    <span class=\"md-list-heading uk-text-large\">{{ category.name }}</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Description</span>
                    <span class=\"md-list-heading uk-text-large\">{{ category.description }}</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Type</span>
                    <span class=\"md-list-heading uk-text-large\">{{ category.type }}</span>
                </div>
            </li>
        </ul>
    </div>
</div>
 

      <div class=\"md-fab-wrapper\">
            <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('category_index') }}\">
            <i class=\"material-icons\">list</i>
            </a>
         
        </div>


{% endblock %}
", "category/show.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app\\Resources\\views\\category\\show.html.twig");
    }
}

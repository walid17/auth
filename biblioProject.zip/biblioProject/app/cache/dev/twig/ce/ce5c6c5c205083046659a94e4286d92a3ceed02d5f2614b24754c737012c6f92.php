<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_75a2d7a75666e174313b0325e6e2a5f65cf839788f9a2828614ffb25397279aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51c74a7f5bb5678ab6128a9525b04232790eca4a1e7491d8cb8008cc87509e6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51c74a7f5bb5678ab6128a9525b04232790eca4a1e7491d8cb8008cc87509e6a->enter($__internal_51c74a7f5bb5678ab6128a9525b04232790eca4a1e7491d8cb8008cc87509e6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_51c74a7f5bb5678ab6128a9525b04232790eca4a1e7491d8cb8008cc87509e6a->leave($__internal_51c74a7f5bb5678ab6128a9525b04232790eca4a1e7491d8cb8008cc87509e6a_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_d72fd03aa52db1145b334d4da59093bd12d2b6ca27ebe2313c8ea8afc31ba0a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d72fd03aa52db1145b334d4da59093bd12d2b6ca27ebe2313c8ea8afc31ba0a7->enter($__internal_d72fd03aa52db1145b334d4da59093bd12d2b6ca27ebe2313c8ea8afc31ba0a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_d72fd03aa52db1145b334d4da59093bd12d2b6ca27ebe2313c8ea8afc31ba0a7->leave($__internal_d72fd03aa52db1145b334d4da59093bd12d2b6ca27ebe2313c8ea8afc31ba0a7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}

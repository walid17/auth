<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_c82754c859c9f986c52091a34d91068bef14e55aba48fd3a2c7c6fff3d6764a4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_812e0ba48f6ce149a4e1806ddbe6b262b1d4855da85c468d50a38e12c7c34b59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_812e0ba48f6ce149a4e1806ddbe6b262b1d4855da85c468d50a38e12c7c34b59->enter($__internal_812e0ba48f6ce149a4e1806ddbe6b262b1d4855da85c468d50a38e12c7c34b59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_812e0ba48f6ce149a4e1806ddbe6b262b1d4855da85c468d50a38e12c7c34b59->leave($__internal_812e0ba48f6ce149a4e1806ddbe6b262b1d4855da85c468d50a38e12c7c34b59_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_0d9b9969636d2e22d033735207b13ea577fafa8ef141239b14b47f31eb9ab592 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d9b9969636d2e22d033735207b13ea577fafa8ef141239b14b47f31eb9ab592->enter($__internal_0d9b9969636d2e22d033735207b13ea577fafa8ef141239b14b47f31eb9ab592_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.subject", array(), "FOSUserBundle");
        echo "
";
        
        $__internal_0d9b9969636d2e22d033735207b13ea577fafa8ef141239b14b47f31eb9ab592->leave($__internal_0d9b9969636d2e22d033735207b13ea577fafa8ef141239b14b47f31eb9ab592_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_27e90dd6e390e1afd1d559ba10e163f74bb7d3fc28c04dbf1ce56afc8c7d7128 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_27e90dd6e390e1afd1d559ba10e163f74bb7d3fc28c04dbf1ce56afc8c7d7128->enter($__internal_27e90dd6e390e1afd1d559ba10e163f74bb7d3fc28c04dbf1ce56afc8c7d7128_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_27e90dd6e390e1afd1d559ba10e163f74bb7d3fc28c04dbf1ce56afc8c7d7128->leave($__internal_27e90dd6e390e1afd1d559ba10e163f74bb7d3fc28c04dbf1ce56afc8c7d7128_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_51a0c06aa48887e4179049bcfd79907abb0bfab973df888ca7b13358d38e2a3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51a0c06aa48887e4179049bcfd79907abb0bfab973df888ca7b13358d38e2a3c->enter($__internal_51a0c06aa48887e4179049bcfd79907abb0bfab973df888ca7b13358d38e2a3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_51a0c06aa48887e4179049bcfd79907abb0bfab973df888ca7b13358d38e2a3c->leave($__internal_51a0c06aa48887e4179049bcfd79907abb0bfab973df888ca7b13358d38e2a3c_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{% autoescape false %}
{{ 'resetting.email.subject'|trans }}
{% endautoescape %}
{% endblock %}
{% block body_text %}
{% autoescape false %}
{{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Resetting:email.txt.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Resetting/email.txt.twig");
    }
}

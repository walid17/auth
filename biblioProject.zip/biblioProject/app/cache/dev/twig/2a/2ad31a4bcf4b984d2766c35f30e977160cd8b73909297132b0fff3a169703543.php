<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_60327ea524ff05880d8915283686ddf458aae436afe21594c37bf6c23a255cd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca571feb2ccd278f923c6c234dc59189aa1ed022339e44461663e506e010090b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca571feb2ccd278f923c6c234dc59189aa1ed022339e44461663e506e010090b->enter($__internal_ca571feb2ccd278f923c6c234dc59189aa1ed022339e44461663e506e010090b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ca571feb2ccd278f923c6c234dc59189aa1ed022339e44461663e506e010090b->leave($__internal_ca571feb2ccd278f923c6c234dc59189aa1ed022339e44461663e506e010090b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_952934844027c408d6e55d548a3737c353fa2a301b06d451239b5fb8fb6fb5ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_952934844027c408d6e55d548a3737c353fa2a301b06d451239b5fb8fb6fb5ce->enter($__internal_952934844027c408d6e55d548a3737c353fa2a301b06d451239b5fb8fb6fb5ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_952934844027c408d6e55d548a3737c353fa2a301b06d451239b5fb8fb6fb5ce->leave($__internal_952934844027c408d6e55d548a3737c353fa2a301b06d451239b5fb8fb6fb5ce_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_137e00926741b5189560a35fc05062beed5dc15529a589edcfea9ac4afc9a380 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_137e00926741b5189560a35fc05062beed5dc15529a589edcfea9ac4afc9a380->enter($__internal_137e00926741b5189560a35fc05062beed5dc15529a589edcfea9ac4afc9a380_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_137e00926741b5189560a35fc05062beed5dc15529a589edcfea9ac4afc9a380->leave($__internal_137e00926741b5189560a35fc05062beed5dc15529a589edcfea9ac4afc9a380_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_dc282a57ebf83dcd8477c8a8d1aecebb1e44f3e86f4b5abe7909d60f74d31fed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc282a57ebf83dcd8477c8a8d1aecebb1e44f3e86f4b5abe7909d60f74d31fed->enter($__internal_dc282a57ebf83dcd8477c8a8d1aecebb1e44f3e86f4b5abe7909d60f74d31fed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_dc282a57ebf83dcd8477c8a8d1aecebb1e44f3e86f4b5abe7909d60f74d31fed->leave($__internal_dc282a57ebf83dcd8477c8a8d1aecebb1e44f3e86f4b5abe7909d60f74d31fed_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}

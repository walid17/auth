<?php

/* livre/show.html.twig */
class __TwigTemplate_d68567b4ee879c7e8a72c40405f535e55659a0d31f29d53be58ba0caf548878f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "livre/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_703203ac45400f09cca5db43b95db1df9eb6907f245d0fd1cfe41f571ed34232 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_703203ac45400f09cca5db43b95db1df9eb6907f245d0fd1cfe41f571ed34232->enter($__internal_703203ac45400f09cca5db43b95db1df9eb6907f245d0fd1cfe41f571ed34232_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "livre/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_703203ac45400f09cca5db43b95db1df9eb6907f245d0fd1cfe41f571ed34232->leave($__internal_703203ac45400f09cca5db43b95db1df9eb6907f245d0fd1cfe41f571ed34232_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_654cdacc89f74c39b24ab507692caf09e71bbcc499ea67db49c4ad6824aa2d14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_654cdacc89f74c39b24ab507692caf09e71bbcc499ea67db49c4ad6824aa2d14->enter($__internal_654cdacc89f74c39b24ab507692caf09e71bbcc499ea67db49c4ad6824aa2d14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo " 
          
           




<div class=\"md-card\">
    <div class=\"md-card-toolbar\">
        <h3 class=\"md-card-toolbar-heading-text\">
            Livre
        </h3>

        <a href=\"#\" style=\" float: right; margin: 10px; \">

             ";
        // line 19
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
             <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
               <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
            </button>

            ";
        // line 24
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "

            
        </a>

        <a href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_edit", array("id" => $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "id", array()))), "html", null, true);
        echo "\" style=\" float: right; margin: 12px;\"><i class=\"material-icons\" style=\" font-size: 22px; \">border_color</i></a>
    </div>
    <div class=\"md-card-content\">
        <ul class=\"md-list\">

     



            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Id</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">";
        // line 41
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "id", array()), "html", null, true);
        echo "</span>
                </div>
            </li>



             <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Acteur</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "acteur", array()), "html", null, true);
        echo "</span>
                </div>
            </li>


             <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Titre</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">";
        // line 58
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "titre", array()), "html", null, true);
        echo "</span>
                </div>
            </li>




         <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Photo</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">
                   
                                <img src=\"/images/products/";
        // line 70
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "imageName", array()), "html", null, true);
        echo "\" style=\"width: 80px;\">
                    </span>
                </div>
            </li>




            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Pdf</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\"> 
                      <a href='/images/pdfs/";
        // line 82
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "imageNam", array()), "html", null, true);
        echo "'>
                              <img src=\"";
        // line 83
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/template/image/pdf.png"), "html", null, true);
        echo "\" style=\"width: 80px;\">
                            </a>  <span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Nbrpage</span>
                    <span class=\"md-list-heading uk-text-large\">";
        // line 90
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "nbrPage", array()), "html", null, true);
        echo "</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Nbrdownload</span>
                    <span class=\"md-list-heading uk-text-large\">";
        // line 96
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "nbrDownload", array()), "html", null, true);
        echo "</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Date</span>
                    <span class=\"md-list-heading uk-text-large\">";
        // line 102
        if ($this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "date", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")), "date", array()), "Y-m-d"), "html", null, true);
        }
        echo "</span>
                </div>
            </li>
        </ul>
    </div>
</div> 

      <div class=\"md-fab-wrapper\">
            <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 110
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_index");
        echo "\">
            <i class=\"material-icons\">list</i>
            </a>
         
        </div>



";
        
        $__internal_654cdacc89f74c39b24ab507692caf09e71bbcc499ea67db49c4ad6824aa2d14->leave($__internal_654cdacc89f74c39b24ab507692caf09e71bbcc499ea67db49c4ad6824aa2d14_prof);

    }

    public function getTemplateName()
    {
        return "livre/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  186 => 110,  173 => 102,  164 => 96,  155 => 90,  145 => 83,  141 => 82,  126 => 70,  111 => 58,  100 => 50,  88 => 41,  73 => 29,  65 => 24,  57 => 19,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
 
          
           




<div class=\"md-card\">
    <div class=\"md-card-toolbar\">
        <h3 class=\"md-card-toolbar-heading-text\">
            Livre
        </h3>

        <a href=\"#\" style=\" float: right; margin: 10px; \">

             {{ form_start(delete_form) }}
             <button type=\"submit\" style=\" background: rgba(255, 0, 0, 0); border-color: rgba(255, 0, 0, 0); \">
               <i style=\" font-size: 25px; \" class=\"material-icons md-24\"></i>
            </button>

            {{ form_end(delete_form) }}

            
        </a>

        <a href=\"{{ path('livre_edit', { 'id': livre.id }) }}\" style=\" float: right; margin: 12px;\"><i class=\"material-icons\" style=\" font-size: 22px; \">border_color</i></a>
    </div>
    <div class=\"md-card-content\">
        <ul class=\"md-list\">

     



            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Id</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">{{ livre.id }}</span>
                </div>
            </li>



             <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Acteur</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">{{ livre.acteur }}</span>
                </div>
            </li>


             <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Titre</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">{{ livre.titre }}</span>
                </div>
            </li>




         <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Photo</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\">
                   
                                <img src=\"/images/products/{{ livre.imageName }}\" style=\"width: 80px;\">
                    </span>
                </div>
            </li>




            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Pdf</span>
                    <span class=\"md-list-heading uk-text-large uk-text-success\"> 
                      <a href='/images/pdfs/{{ livre.imageNam }}'>
                              <img src=\"{{ asset('/template/image/pdf.png') }}\" style=\"width: 80px;\">
                            </a>  <span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Nbrpage</span>
                    <span class=\"md-list-heading uk-text-large\">{{ livre.nbrPage }}</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Nbrdownload</span>
                    <span class=\"md-list-heading uk-text-large\">{{ livre.nbrDownload }}</span>
                </div>
            </li>
            <li>
                <div class=\"md-list-content\">
                    <span class=\"uk-text-small uk-text-muted uk-display-block\">Date</span>
                    <span class=\"md-list-heading uk-text-large\">{% if livre.date %}{{ livre.date|date('Y-m-d') }}{% endif %}</span>
                </div>
            </li>
        </ul>
    </div>
</div> 

      <div class=\"md-fab-wrapper\">
            <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('livre_index') }}\">
            <i class=\"material-icons\">list</i>
            </a>
         
        </div>



{% endblock %}
", "livre/show.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app\\Resources\\views\\livre\\show.html.twig");
    }
}

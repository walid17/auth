<?php

/* AcmeBiblioBundle:Default:index.html.twig */
class __TwigTemplate_aabad610d2efd02d38906f7ef9b91d90b9be1ac71a91a89db80db4c6cf074963 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c66acae08a52b3b274423039fcd3109940b0ebe55e3b35d5111d723ac4cabd48 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c66acae08a52b3b274423039fcd3109940b0ebe55e3b35d5111d723ac4cabd48->enter($__internal_c66acae08a52b3b274423039fcd3109940b0ebe55e3b35d5111d723ac4cabd48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AcmeBiblioBundle:Default:index.html.twig"));

        // line 1
        echo "

        <!DOCTYPE html>
<html>
     <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 23
        echo "        <link rel=\"icon\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
  
    <body class=\"login_page\" style=\"margin: 0 auto;padding-left:2%;\">

<header id=\"header_main\">
        <div class=\"header_main_content\">
            <nav class=\"uk-navbar\">
                <!-- main sidebar switch -->
               
                <div class=\"uk-navbar-flip\">
                    <ul class=\"uk-navbar-nav user_actions\">
                        <li><a href=\"#\" id=\"main_search_btn\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE8B6;</i></a></li>
                        <li data-uk-dropdown=\"{mode:'click'}\" class=\"uk-hidden-small\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE0BE;</i><span class=\"uk-badge\">12</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-cyan\">yq</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Ipsum sed ipsam.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Cum architecto assumenda corporis aut qui eum occaecati in accusamus sint.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"";
        // line 51
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/avatars/avatar_07_tn.png"), "html", null, true);
        echo "\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Atque occaecati.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Et accusantium libero praesentium placeat quod perspiciatis et.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-light-green\">ao</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolor magnam iste.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Qui explicabo sit qui fugit corrupti sit in nesciunt.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/avatars/avatar_09_tn.png"), "html", null, true);
        echo "\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolore placeat.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Reprehenderit eum quam animi quia natus rem autem voluptatem voluptas earum.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/avatars/avatar_09_tn.png"), "html", null, true);
        echo "\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Voluptatum incidunt atque.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Eaque omnis nam eius quos sunt ut ipsa molestias.</span>
                                        </div>
                                    </li>
                                </ul>
                                <a href=\"page_mailbox.html\" class=\"md-btn md-btn-flat md-btn-flat-primary md-btn-block js-uk-prevent uk-margin-small-top\">Show All</a>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE7F4;</i><span class=\"uk-badge\">4</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-warning\">&#xE8B2;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Nesciunt natus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Alias sunt sint labore officiis ut.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-success\">&#xE88F;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Iusto reiciendis non.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Quaerat neque eum perspiciatis quasi officiis corporis exercitationem.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-danger\">&#xE001;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Enim suscipit.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Ea non omnis at consequatur.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-primary\">&#xE8FD;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Ea necessitatibus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Voluptatibus reiciendis quasi est enim aut et in error.</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_image\"><img class=\"md-user-image\" src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/template/assets/img/avatars/avatar_11_tn.png"), "html", null, true);
        echo "\" alt=\"\"/></a>
                            <div class=\"uk-dropdown uk-dropdown-small uk-dropdown-flip\">
                                <ul class=\"uk-nav js-uk-prevent\">
                                     ";
        // line 136
        if (($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER") == true)) {
            // line 137
            echo "                                    <li><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("Logout");
            echo "\">Logout</a></li>
                                     ";
        } else {
            // line 139
            echo "   \t\t\t\t\t\t\t\t<li><a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">Login</a></li>

\t\t\t\t\t\t\t\t\t";
        }
        // line 142
        echo "                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class=\"header_main_search_form\">
            <i class=\"md-icon header_main_search_close material-icons\">&#xE5CD;</i>
            <form class=\"uk-form\">
                <input type=\"text\" class=\"header_main_search_input\" />
                <button class=\"header_main_search_btn uk-button-link\"><i class=\"md-icon material-icons\">&#xE8B6;</i></button>
            </form>
        </div>
    </header><!-- main header end -->





<div id=\"page_content\">
        <div id=\"page_content_inner \">


\t<div style=\" margin: 0 auto;display: block;width: 190px;margin-top: 40px; \">
\t\t<img src=\"";
        // line 167
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/template/assets/img/logo.png"), "html", null, true);
        echo "\" alt=\"\" height=\"130\" width=\"130\" style=\" margin: 14px; \" class=\"\">
\t</div>

\t\t\t<div class=\"md-card  hierarchical_show\" style=\"width: 98%; \" >
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-star \" style=\" color: #F44336; \"></i> Top 5 Download
                    </h3>
                     
                </div>
            </div>
 


        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">



";
        // line 186
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["livre"]) ? $context["livre"] : $this->getContext($context, "livre")));
        foreach ($context['_seq'] as $context["_key"] => $context["l"]) {
            // line 187
            echo "           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\" style=\" width: 22%;\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"";
            // line 199
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/images/products/" . $this->getAttribute($context["l"], "imageName", array()))), "html", null, true);
            echo "  \"  style=\" width: 90%; \"/>
                            </div>

                           



                        <div class=\"md-card-overlay-content\" >
                        ";
            // line 207
            if (($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER") == true)) {
                // line 208
                echo "                  \t <a class=\"md-fab md-fab-small md-fab-accent\"  href=\"/images/pdfs/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "imageNam", array()), "html", null, true);
                echo "\"
                     onclick=\"newDoc(";
                // line 209
                echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "id", array()), "html", null, true);
                echo ")\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\" download>
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a> ";
            }
            // line 213
            echo "                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   ";
            // line 216
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "titre", array()), "html", null, true);
            echo "
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  ";
            // line 230
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "acteur", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 246
            if ($this->getAttribute($context["l"], "date", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["l"], "date", array()), "Y-m-d"), "html", null, true);
            }
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 256
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrDownload", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 266
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrPage", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['l'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 284
        echo "
                 



            </div>


\t\t<div class=\"md-card  hierarchical_show\" style=\"margin-top: 20px; width: 98%; \">
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-book \" style=\" color: #F44336; \"></i> Livre Recent
                    </h3>
                     
                </div>
            </div>





        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">


";
        // line 309
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["top"]) ? $context["top"] : $this->getContext($context, "top")));
        foreach ($context['_seq'] as $context["_key"] => $context["l"]) {
            // line 310
            echo "           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\" style=\" width: 22%;\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"";
            // line 322
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/images/products/" . $this->getAttribute($context["l"], "imageName", array()))), "html", null, true);
            echo "\"  style=\" width: 90%; \"/>
                            </div>

                           



                        <div class=\"md-card-overlay-content\" >
                        ";
            // line 330
            if (($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_USER") == true)) {
                // line 331
                echo "                  \t <a class=\"md-fab md-fab-small md-fab-accent\"  href=\"/images/pdfs/";
                echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "imageNam", array()), "html", null, true);
                echo "\"
                     onclick=\"newDoc(";
                // line 332
                echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "id", array()), "html", null, true);
                echo ")\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\" download>
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a> ";
            }
            // line 336
            echo "                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   ";
            // line 339
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "titre", array()), "html", null, true);
            echo "
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  ";
            // line 353
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "acteur", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 369
            if ($this->getAttribute($context["l"], "date", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["l"], "date", array()), "Y-m-d"), "html", null, true);
            }
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 379
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrDownload", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">";
            // line 389
            echo twig_escape_filter($this->env, $this->getAttribute($context["l"], "nbrPage", array()), "html", null, true);
            echo "</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['l'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 407
        echo "



            </div>




   \t </div>


    </div>

 

<style type=\"text/css\">
    

    #acme_bibliobundle_livre_date_year{
 width: 10%;
 float: left;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


   #acme_bibliobundle_livre_date_month {
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


    #acme_bibliobundle_livre_date_day{
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }

    .uk-grid-width-large-1-4>* {
    width: 24.5%;
}


</style>





    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
 

        ";
        // line 507
        $this->displayBlock('javascripts', $context, $blocks);
        // line 520
        echo "    </body>
</html>
";
        
        $__internal_c66acae08a52b3b274423039fcd3109940b0ebe55e3b35d5111d723ac4cabd48->leave($__internal_c66acae08a52b3b274423039fcd3109940b0ebe55e3b35d5111d723ac4cabd48_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_f47ec3d415ad99fc1282da6fb6adb2d9d1956a1f499cecc93adc9482b654220d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f47ec3d415ad99fc1282da6fb6adb2d9d1956a1f499cecc93adc9482b654220d->enter($__internal_f47ec3d415ad99fc1282da6fb6adb2d9d1956a1f499cecc93adc9482b654220d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_f47ec3d415ad99fc1282da6fb6adb2d9d1956a1f499cecc93adc9482b654220d->leave($__internal_f47ec3d415ad99fc1282da6fb6adb2d9d1956a1f499cecc93adc9482b654220d_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1d22c88e690035767fcdfa352d21244ef02bf102ca528ffbb3b8773775654876 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d22c88e690035767fcdfa352d21244ef02bf102ca528ffbb3b8773775654876->enter($__internal_1d22c88e690035767fcdfa352d21244ef02bf102ca528ffbb3b8773775654876_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "

     <script>
function newDoc(val) {
     var path=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_update", array("id" => "PLACEHOLDER"));
        echo "\";
       var url =  path.replace(\"PLACEHOLDER\", val);
  \t\t window.location.assign(url);
}
</script>

     <link  rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/bower_components/uikit/css/uikit.almost-flat.min.css"), "html", null, true);
        echo "\" />
     <link  rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/css/main.min.css"), "html", null, true);
        echo "\" />
     <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/icons/flags/flags.min.css"), "html", null, true);
        echo "\" /> 
        ";
        
        $__internal_1d22c88e690035767fcdfa352d21244ef02bf102ca528ffbb3b8773775654876->leave($__internal_1d22c88e690035767fcdfa352d21244ef02bf102ca528ffbb3b8773775654876_prof);

    }

    // line 507
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_931dd56888327bc15740c2c0d5a3268d5e949c8e8364e833717b7b8cb0f2d6d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_931dd56888327bc15740c2c0d5a3268d5e949c8e8364e833717b7b8cb0f2d6d5->enter($__internal_931dd56888327bc15740c2c0d5a3268d5e949c8e8364e833717b7b8cb0f2d6d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 508
        echo "   <script   type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/bower_components/moment/min/moment.min.js"), "html", null, true);
        echo "\" ></script>
  <script  type=\"text/javascript\" src=\"";
        // line 509
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/common.min.js"), "html", null, true);
        echo "\"></script>
 <script   type=\"text/javascript\" src=\"";
        // line 510
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/uikit_custom.min.js"), "html", null, true);
        echo "\" ></script>
 <script   type=\"text/javascript\" src=\"";
        // line 511
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/altair_admin_common.min.js"), "html", null, true);
        echo "\" ></script>
    <!-- enable hires images -->
    <script>
        \$(function() {
            altair_helpers.retina_images();
        });
    </script>

        ";
        
        $__internal_931dd56888327bc15740c2c0d5a3268d5e949c8e8364e833717b7b8cb0f2d6d5->leave($__internal_931dd56888327bc15740c2c0d5a3268d5e949c8e8364e833717b7b8cb0f2d6d5_prof);

    }

    public function getTemplateName()
    {
        return "AcmeBiblioBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  713 => 511,  709 => 510,  705 => 509,  700 => 508,  694 => 507,  685 => 21,  681 => 20,  677 => 19,  668 => 13,  662 => 9,  656 => 8,  644 => 7,  635 => 520,  633 => 507,  531 => 407,  507 => 389,  494 => 379,  479 => 369,  460 => 353,  443 => 339,  438 => 336,  431 => 332,  426 => 331,  424 => 330,  413 => 322,  399 => 310,  395 => 309,  368 => 284,  344 => 266,  331 => 256,  316 => 246,  297 => 230,  280 => 216,  275 => 213,  268 => 209,  263 => 208,  261 => 207,  250 => 199,  236 => 187,  232 => 186,  210 => 167,  183 => 142,  176 => 139,  170 => 137,  168 => 136,  162 => 133,  104 => 78,  92 => 69,  71 => 51,  39 => 23,  37 => 8,  33 => 7,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("

        <!DOCTYPE html>
<html>
     <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}


     <script>
function newDoc(val) {
     var path=\"{{ path('livre_update', { 'id':\"PLACEHOLDER\"  }) }}\";
       var url =  path.replace(\"PLACEHOLDER\", val);
  \t\t window.location.assign(url);
}
</script>

     <link  rel=\"stylesheet\" href=\"{{ asset('template/bower_components/uikit/css/uikit.almost-flat.min.css') }}\" />
     <link  rel=\"stylesheet\" href=\"{{ asset('template/assets/css/main.min.css') }}\" />
     <link rel=\"stylesheet\" href=\"{{ asset('template/assets/icons/flags/flags.min.css') }}\" /> 
        {% endblock %}
        <link rel=\"icon\" type=\"text/css\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
  
    <body class=\"login_page\" style=\"margin: 0 auto;padding-left:2%;\">

<header id=\"header_main\">
        <div class=\"header_main_content\">
            <nav class=\"uk-navbar\">
                <!-- main sidebar switch -->
               
                <div class=\"uk-navbar-flip\">
                    <ul class=\"uk-navbar-nav user_actions\">
                        <li><a href=\"#\" id=\"main_search_btn\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE8B6;</i></a></li>
                        <li data-uk-dropdown=\"{mode:'click'}\" class=\"uk-hidden-small\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE0BE;</i><span class=\"uk-badge\">12</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-cyan\">yq</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Ipsum sed ipsam.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Cum architecto assumenda corporis aut qui eum occaecati in accusamus sint.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"{{ asset('template/assets/img/avatars/avatar_07_tn.png')}}\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Atque occaecati.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Et accusantium libero praesentium placeat quod perspiciatis et.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-light-green\">ao</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolor magnam iste.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Qui explicabo sit qui fugit corrupti sit in nesciunt.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"{{ asset('template/assets/img/avatars/avatar_09_tn.png') }}\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolore placeat.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Reprehenderit eum quam animi quia natus rem autem voluptatem voluptas earum.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"{{ asset('template/assets/img/avatars/avatar_09_tn.png') }}\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Voluptatum incidunt atque.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Eaque omnis nam eius quos sunt ut ipsa molestias.</span>
                                        </div>
                                    </li>
                                </ul>
                                <a href=\"page_mailbox.html\" class=\"md-btn md-btn-flat md-btn-flat-primary md-btn-block js-uk-prevent uk-margin-small-top\">Show All</a>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE7F4;</i><span class=\"uk-badge\">4</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-warning\">&#xE8B2;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Nesciunt natus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Alias sunt sint labore officiis ut.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-success\">&#xE88F;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Iusto reiciendis non.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Quaerat neque eum perspiciatis quasi officiis corporis exercitationem.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-danger\">&#xE001;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Enim suscipit.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Ea non omnis at consequatur.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-primary\">&#xE8FD;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Ea necessitatibus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Voluptatibus reiciendis quasi est enim aut et in error.</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_image\"><img class=\"md-user-image\" src=\"{{ asset('/template/assets/img/avatars/avatar_11_tn.png') }}\" alt=\"\"/></a>
                            <div class=\"uk-dropdown uk-dropdown-small uk-dropdown-flip\">
                                <ul class=\"uk-nav js-uk-prevent\">
                                     {% if is_granted('ROLE_USER') == true %}
                                    <li><a href=\"{{ path('Logout') }}\">Logout</a></li>
                                     {% else%}
   \t\t\t\t\t\t\t\t<li><a href=\"{{ path('fos_user_security_login') }}\">Login</a></li>

\t\t\t\t\t\t\t\t\t{% endif %}
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class=\"header_main_search_form\">
            <i class=\"md-icon header_main_search_close material-icons\">&#xE5CD;</i>
            <form class=\"uk-form\">
                <input type=\"text\" class=\"header_main_search_input\" />
                <button class=\"header_main_search_btn uk-button-link\"><i class=\"md-icon material-icons\">&#xE8B6;</i></button>
            </form>
        </div>
    </header><!-- main header end -->





<div id=\"page_content\">
        <div id=\"page_content_inner \">


\t<div style=\" margin: 0 auto;display: block;width: 190px;margin-top: 40px; \">
\t\t<img src=\"{{asset('/template/assets/img/logo.png')}}\" alt=\"\" height=\"130\" width=\"130\" style=\" margin: 14px; \" class=\"\">
\t</div>

\t\t\t<div class=\"md-card  hierarchical_show\" style=\"width: 98%; \" >
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-star \" style=\" color: #F44336; \"></i> Top 5 Download
                    </h3>
                     
                </div>
            </div>
 


        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">



{% for l in livre %}
           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\" style=\" width: 22%;\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"{{asset('/images/products/'~l.imageName)}}  \"  style=\" width: 90%; \"/>
                            </div>

                           



                        <div class=\"md-card-overlay-content\" >
                        {% if is_granted('ROLE_USER') == true %}
                  \t <a class=\"md-fab md-fab-small md-fab-accent\"  href=\"/images/pdfs/{{ l.imageNam }}\"
                     onclick=\"newDoc({{l.id}})\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\" download>
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a> {% endif %}
                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   {{ l.titre }}
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  {{ l.acteur }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{% if l.date %}{{ l.date|date('Y-m-d') }}{% endif %}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrDownload }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrPage }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        {% endfor %}

                 



            </div>


\t\t<div class=\"md-card  hierarchical_show\" style=\"margin-top: 20px; width: 98%; \">
                <div class=\"md-card-content\">

                    <h3 class=\"heading_a\">
 \t\t\t\t\t\t<i class=\"uk-icon-book \" style=\" color: #F44336; \"></i> Livre Recent
                    </h3>
                     
                </div>
            </div>





        <div class=\"uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show\" data-uk-grid=\"{gutter: 20, controls: '#products_sort'}\" style=\"margin-top: 20px;\">


{% for l in top %}
           
            
                 
                 


                <div data-product-name=\"Rerum laborum.\" style=\" width: 22%;\">
                   
                 <div class=\"md-card md-card-hover md-card-overlay\" style=\" height: 220px; \">
                        
                        <div class=\"md-card-content truncate-text is-truncated\" style=\"word-wrap: break-word;height: auto;\">
                           
                            <img class=\"md-card-head-img\" src=\"{{asset('/images/products/'~l.imageName)}}\"  style=\" width: 90%; \"/>
                            </div>

                           



                        <div class=\"md-card-overlay-content\" >
                        {% if is_granted('ROLE_USER') == true %}
                  \t <a class=\"md-fab md-fab-small md-fab-accent\"  href=\"/images/pdfs/{{ l.imageNam }}\"
                     onclick=\"newDoc({{l.id}})\" style=\"position: absolute;margin-top: -36px;    background: #0277bd;\" download>
                                
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-download uk-icon-medium\"></i>
                            </a> {% endif %}
                            <div class=\"uk-clearfix md-card-overlay-header\">
                                <i class=\"md-icon md-icon material-icons md-card-overlay-toggler\"></i>
                                <h3>
                                   {{ l.titre }}
                                </h3>
                            </div>

                            <p class=\"truncate-text\" style=\"word-wrap: break-word;\">

 \t\t\t\t\t\t\t\t<ul class=\"md-list md-list-addon\" style=\" margin-top: -10px; \">
                                <li>
                                    <div class=\"md-list-addon-element\">


                                     <i class=\"uk-icon-user uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">  {{ l.acteur }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Acteur</span>
                                    </div>
                                </li>







                                  <li>
                                    <div class=\"md-list-addon-element\">
\t\t\t\t\t\t\t\t\t<i class=\"uk-icon-calendar uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{% if l.date %}{{ l.date|date('Y-m-d') }}{% endif %}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Date</span>
                                    </div>
                                </li>
                                <li>
                                    <div class=\"md-list-addon-element\">
                                  <i class=\"uk-icon-download uk-icon-medium\"></i>

                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrDownload }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre Download</span>
                                    </div>
                                </li>
                                
                                <li>
                                    <div class=\"md-list-addon-element\">
                                          <i class=\"uk-icon-file-pdf-o uk-icon-medium\"></i>
                                    </div>
                                    <div class=\"md-list-content\">
                                        <span class=\"md-list-heading\">{{ l.nbrPage }}</span>
                                        <span class=\"uk-text-small uk-text-muted\">Nombre De Page</span>
                                    </div>
                                </li>
                               

                            </ul>

                            </p>
                        </div>
                    </div>

                    
                </div>
               


        {% endfor %}




            </div>




   \t </div>


    </div>

 

<style type=\"text/css\">
    

    #acme_bibliobundle_livre_date_year{
 width: 10%;
 float: left;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


   #acme_bibliobundle_livre_date_month {
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


    #acme_bibliobundle_livre_date_day{
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }

    .uk-grid-width-large-1-4>* {
    width: 24.5%;
}


</style>





    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
 

        {% block javascripts %}
   <script   type=\"text/javascript\" src=\"{{ asset('template/bower_components/moment/min/moment.min.js') }}\" ></script>
  <script  type=\"text/javascript\" src=\"{{ asset('template/assets/js/common.min.js') }}\"></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/uikit_custom.min.js') }}\" ></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/altair_admin_common.min.js') }}\" ></script>
    <!-- enable hires images -->
    <script>
        \$(function() {
            altair_helpers.retina_images();
        });
    </script>

        {% endblock %}
    </body>
</html>
", "AcmeBiblioBundle:Default:index.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\src\\Acme\\BiblioBundle\\Resources\\views\\Default\\index.html.twig");
    }
}

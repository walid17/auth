<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_48cacad58c7a59479c8094a9f29372f3a004499369045324b7da3009d9fd0acb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_023742da2ad64824f30d8df9e0a310a4c37c5b3fbabbbd4d3ff5c7a9a72498c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_023742da2ad64824f30d8df9e0a310a4c37c5b3fbabbbd4d3ff5c7a9a72498c8->enter($__internal_023742da2ad64824f30d8df9e0a310a4c37c5b3fbabbbd4d3ff5c7a9a72498c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_023742da2ad64824f30d8df9e0a310a4c37c5b3fbabbbd4d3ff5c7a9a72498c8->leave($__internal_023742da2ad64824f30d8df9e0a310a4c37c5b3fbabbbd4d3ff5c7a9a72498c8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\percent_widget.html.php");
    }
}

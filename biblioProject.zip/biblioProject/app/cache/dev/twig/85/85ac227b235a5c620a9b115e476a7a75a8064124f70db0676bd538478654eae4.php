<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_c613149a0ac90b26357e2c5e2fbb2d9eb8aabc157ad202ad97ba58e2397a7c00 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_984206b2ae59e188d3ae71985fbf82f699ce6e1ad1d47cd6bcfeb1c0f3b6faed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_984206b2ae59e188d3ae71985fbf82f699ce6e1ad1d47cd6bcfeb1c0f3b6faed->enter($__internal_984206b2ae59e188d3ae71985fbf82f699ce6e1ad1d47cd6bcfeb1c0f3b6faed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_984206b2ae59e188d3ae71985fbf82f699ce6e1ad1d47cd6bcfeb1c0f3b6faed->leave($__internal_984206b2ae59e188d3ae71985fbf82f699ce6e1ad1d47cd6bcfeb1c0f3b6faed_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f3c9ae552c60f87cf63a7df9a4dc5a6c81b18525cc158f2325211c66b1c5e295 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f3c9ae552c60f87cf63a7df9a4dc5a6c81b18525cc158f2325211c66b1c5e295->enter($__internal_f3c9ae552c60f87cf63a7df9a4dc5a6c81b18525cc158f2325211c66b1c5e295_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_f3c9ae552c60f87cf63a7df9a4dc5a6c81b18525cc158f2325211c66b1c5e295->leave($__internal_f3c9ae552c60f87cf63a7df9a4dc5a6c81b18525cc158f2325211c66b1c5e295_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:list_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:list.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Group/list.html.twig");
    }
}

<?php

/* @FOSUser/ChangePassword/changePassword.html.twig */
class __TwigTemplate_703ad2f8a7d6af1b4443fb1b12f159aaea4a4bcada94b6e2eb6726822f1876ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/ChangePassword/changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d8ed7c1756e247fe3b3f242317503af62ab294972f0d0b6e1f326618444163f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d8ed7c1756e247fe3b3f242317503af62ab294972f0d0b6e1f326618444163f->enter($__internal_8d8ed7c1756e247fe3b3f242317503af62ab294972f0d0b6e1f326618444163f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/ChangePassword/changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8d8ed7c1756e247fe3b3f242317503af62ab294972f0d0b6e1f326618444163f->leave($__internal_8d8ed7c1756e247fe3b3f242317503af62ab294972f0d0b6e1f326618444163f_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_fc6b9871e90fe9a8bc53df67eae5a23c4baf6b2f3fd07a2b9425fda7532b64d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc6b9871e90fe9a8bc53df67eae5a23c4baf6b2f3fd07a2b9425fda7532b64d1->enter($__internal_fc6b9871e90fe9a8bc53df67eae5a23c4baf6b2f3fd07a2b9425fda7532b64d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "@FOSUser/ChangePassword/changePassword.html.twig", 4)->display($context);
        
        $__internal_fc6b9871e90fe9a8bc53df67eae5a23c4baf6b2f3fd07a2b9425fda7532b64d1->leave($__internal_fc6b9871e90fe9a8bc53df67eae5a23c4baf6b2f3fd07a2b9425fda7532b64d1_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/ChangePassword/changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:ChangePassword:changePassword_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/ChangePassword/changePassword.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\ChangePassword\\changePassword.html.twig");
    }
}

<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_0615396a1b44c89abaf582ebf0b30cab43b7e2fef6c0e421db92bd93522aa74c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_71c8a708aea427e02ae6d54aa64bd72b6ce4454bad14fafce6a29a35400b71b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_71c8a708aea427e02ae6d54aa64bd72b6ce4454bad14fafce6a29a35400b71b5->enter($__internal_71c8a708aea427e02ae6d54aa64bd72b6ce4454bad14fafce6a29a35400b71b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_71c8a708aea427e02ae6d54aa64bd72b6ce4454bad14fafce6a29a35400b71b5->leave($__internal_71c8a708aea427e02ae6d54aa64bd72b6ce4454bad14fafce6a29a35400b71b5_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_f59000cd714fc9ece4adb257d06122c648ba719fbfbcede4452b851ef37cd51d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f59000cd714fc9ece4adb257d06122c648ba719fbfbcede4452b851ef37cd51d->enter($__internal_f59000cd714fc9ece4adb257d06122c648ba719fbfbcede4452b851ef37cd51d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_f59000cd714fc9ece4adb257d06122c648ba719fbfbcede4452b851ef37cd51d->leave($__internal_f59000cd714fc9ece4adb257d06122c648ba719fbfbcede4452b851ef37cd51d_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_a64cc142a492a01650165cab4a29cc9e942cc4cfb3a3680272f8fba6c1828180 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a64cc142a492a01650165cab4a29cc9e942cc4cfb3a3680272f8fba6c1828180->enter($__internal_a64cc142a492a01650165cab4a29cc9e942cc4cfb3a3680272f8fba6c1828180_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_a64cc142a492a01650165cab4a29cc9e942cc4cfb3a3680272f8fba6c1828180->leave($__internal_a64cc142a492a01650165cab4a29cc9e942cc4cfb3a3680272f8fba6c1828180_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_9b44538aa453ac0c395b7f22ab09b08ffb840b5976fc00f8c0208399d3ad9a1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b44538aa453ac0c395b7f22ab09b08ffb840b5976fc00f8c0208399d3ad9a1a->enter($__internal_9b44538aa453ac0c395b7f22ab09b08ffb840b5976fc00f8c0208399d3ad9a1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_9b44538aa453ac0c395b7f22ab09b08ffb840b5976fc00f8c0208399d3ad9a1a->leave($__internal_9b44538aa453ac0c395b7f22ab09b08ffb840b5976fc00f8c0208399d3ad9a1a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% trans_default_domain 'FOSUserBundle' %}
{% block subject %}
{% autoescape false %}
{{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_text %}
{% autoescape false %}
{{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}
{% endautoescape %}
{% endblock %}
{% block body_html %}{% endblock %}
", "FOSUserBundle:Registration:email.txt.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Registration/email.txt.twig");
    }
}

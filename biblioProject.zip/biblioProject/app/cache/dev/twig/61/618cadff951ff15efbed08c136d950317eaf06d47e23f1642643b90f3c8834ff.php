<?php

/* @FOSUser/Registration/checkEmail.html.twig */
class __TwigTemplate_cac5138b9a79069f2891c4a8493d33eedae63e91b8678fdcbcb24fdcc414a4d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Registration/checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b25d8b1e40464153136a55629cfba1d9d992be48a4efa58d427d2e4eac5c72a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b25d8b1e40464153136a55629cfba1d9d992be48a4efa58d427d2e4eac5c72a->enter($__internal_4b25d8b1e40464153136a55629cfba1d9d992be48a4efa58d427d2e4eac5c72a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Registration/checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b25d8b1e40464153136a55629cfba1d9d992be48a4efa58d427d2e4eac5c72a->leave($__internal_4b25d8b1e40464153136a55629cfba1d9d992be48a4efa58d427d2e4eac5c72a_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_6353311b4529ab6c56d16dc691d1730a16b7bbc5de2ece6d8f55909ec160b362 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6353311b4529ab6c56d16dc691d1730a16b7bbc5de2ece6d8f55909ec160b362->enter($__internal_6353311b4529ab6c56d16dc691d1730a16b7bbc5de2ece6d8f55909ec160b362_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_6353311b4529ab6c56d16dc691d1730a16b7bbc5de2ece6d8f55909ec160b362->leave($__internal_6353311b4529ab6c56d16dc691d1730a16b7bbc5de2ece6d8f55909ec160b362_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Registration/checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% trans_default_domain 'FOSUserBundle' %}

{% block fos_user_content %}
    <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>
{% endblock fos_user_content %}
", "@FOSUser/Registration/checkEmail.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Registration\\checkEmail.html.twig");
    }
}

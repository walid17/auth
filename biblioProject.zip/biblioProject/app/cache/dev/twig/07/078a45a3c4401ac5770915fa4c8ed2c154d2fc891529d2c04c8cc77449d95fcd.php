<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_dedcf98f82c1189a2e773d4b0ce25ac20d2bab6e6072ad3bf8177d7917428d68 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90a2170bf899d67fb8023060359f22bcc9da96f15ac905e958900246f39e2e6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90a2170bf899d67fb8023060359f22bcc9da96f15ac905e958900246f39e2e6b->enter($__internal_90a2170bf899d67fb8023060359f22bcc9da96f15ac905e958900246f39e2e6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_90a2170bf899d67fb8023060359f22bcc9da96f15ac905e958900246f39e2e6b->leave($__internal_90a2170bf899d67fb8023060359f22bcc9da96f15ac905e958900246f39e2e6b_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_9820023ea367e53ef3ebcda2e421d54f6b0e27bd7cc7f4b6223d40c42a70a0cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9820023ea367e53ef3ebcda2e421d54f6b0e27bd7cc7f4b6223d40c42a70a0cc->enter($__internal_9820023ea367e53ef3ebcda2e421d54f6b0e27bd7cc7f4b6223d40c42a70a0cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_9820023ea367e53ef3ebcda2e421d54f6b0e27bd7cc7f4b6223d40c42a70a0cc->leave($__internal_9820023ea367e53ef3ebcda2e421d54f6b0e27bd7cc7f4b6223d40c42a70a0cc_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:show_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Group:show.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle/Resources/views/Group/show.html.twig");
    }
}

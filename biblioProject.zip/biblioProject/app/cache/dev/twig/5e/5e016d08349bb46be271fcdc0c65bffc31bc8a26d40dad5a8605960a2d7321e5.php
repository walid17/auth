<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_380c7ca4eec5d550b1aff283eef0729b74e5a9569a09f5f7766fe2a66632374b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ab696fa41bb8a8cd0a5512e4da005a086129a455a7d67b0849a1aab6373b5b4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab696fa41bb8a8cd0a5512e4da005a086129a455a7d67b0849a1aab6373b5b4b->enter($__internal_ab696fa41bb8a8cd0a5512e4da005a086129a455a7d67b0849a1aab6373b5b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_ab696fa41bb8a8cd0a5512e4da005a086129a455a7d67b0849a1aab6373b5b4b->leave($__internal_ab696fa41bb8a8cd0a5512e4da005a086129a455a7d67b0849a1aab6373b5b4b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}

<?php

/* @FOSUser/Group/show.html.twig */
class __TwigTemplate_945e2ededbadf9756b5d58c3ea0f12fe1195fbfd8f97d1b0c80bc3883cb46a5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Group/show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6884c0a611d723467afe37d543d6ae36c48f9dee886636624b7251843e646050 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6884c0a611d723467afe37d543d6ae36c48f9dee886636624b7251843e646050->enter($__internal_6884c0a611d723467afe37d543d6ae36c48f9dee886636624b7251843e646050_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6884c0a611d723467afe37d543d6ae36c48f9dee886636624b7251843e646050->leave($__internal_6884c0a611d723467afe37d543d6ae36c48f9dee886636624b7251843e646050_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_2137c4c6f62802ea8d6c02f2b09b4511a981c28f3f846f2a8cdaa198bb4c9c19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2137c4c6f62802ea8d6c02f2b09b4511a981c28f3f846f2a8cdaa198bb4c9c19->enter($__internal_2137c4c6f62802ea8d6c02f2b09b4511a981c28f3f846f2a8cdaa198bb4c9c19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "@FOSUser/Group/show.html.twig", 4)->display($context);
        
        $__internal_2137c4c6f62802ea8d6c02f2b09b4511a981c28f3f846f2a8cdaa198bb4c9c19->leave($__internal_2137c4c6f62802ea8d6c02f2b09b4511a981c28f3f846f2a8cdaa198bb4c9c19_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:show_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/show.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\show.html.twig");
    }
}

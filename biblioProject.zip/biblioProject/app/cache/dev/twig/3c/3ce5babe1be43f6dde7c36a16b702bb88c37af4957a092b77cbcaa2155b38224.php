<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_e13e91d3e003bb79a673ec7c6ba45e31b8506e32b83e34ea09c20485244892ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_691a1f1a08255e667aef84d1f174fd1c1d484886b3c5814d220cac364ed5e647 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_691a1f1a08255e667aef84d1f174fd1c1d484886b3c5814d220cac364ed5e647->enter($__internal_691a1f1a08255e667aef84d1f174fd1c1d484886b3c5814d220cac364ed5e647_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_691a1f1a08255e667aef84d1f174fd1c1d484886b3c5814d220cac364ed5e647->leave($__internal_691a1f1a08255e667aef84d1f174fd1c1d484886b3c5814d220cac364ed5e647_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_f9b194aed818e359e3f1d0b15ffcc79a807862d96468b399dfef6a5c132ce679 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9b194aed818e359e3f1d0b15ffcc79a807862d96468b399dfef6a5c132ce679->enter($__internal_f9b194aed818e359e3f1d0b15ffcc79a807862d96468b399dfef6a5c132ce679_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_f9b194aed818e359e3f1d0b15ffcc79a807862d96468b399dfef6a5c132ce679->leave($__internal_f9b194aed818e359e3f1d0b15ffcc79a807862d96468b399dfef6a5c132ce679_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_a6c0c81bf50e2e50be8fb8d3ba116b3343b154b432b9e37c5245de526195ed94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6c0c81bf50e2e50be8fb8d3ba116b3343b154b432b9e37c5245de526195ed94->enter($__internal_a6c0c81bf50e2e50be8fb8d3ba116b3343b154b432b9e37c5245de526195ed94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_a6c0c81bf50e2e50be8fb8d3ba116b3343b154b432b9e37c5245de526195ed94->leave($__internal_a6c0c81bf50e2e50be8fb8d3ba116b3343b154b432b9e37c5245de526195ed94_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}

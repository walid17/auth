<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_19b78979b02897e9188a70d30b60ffc9609a3ba930256f4353e3686849ba0f3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b2629492b6ed3fe279827b48a6112c9ca7b3596ab82fcbf979ad72d4d2c3a7de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2629492b6ed3fe279827b48a6112c9ca7b3596ab82fcbf979ad72d4d2c3a7de->enter($__internal_b2629492b6ed3fe279827b48a6112c9ca7b3596ab82fcbf979ad72d4d2c3a7de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_b2629492b6ed3fe279827b48a6112c9ca7b3596ab82fcbf979ad72d4d2c3a7de->leave($__internal_b2629492b6ed3fe279827b48a6112c9ca7b3596ab82fcbf979ad72d4d2c3a7de_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}

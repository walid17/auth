<?php

/* ::base.html.twig */
class __TwigTemplate_9ed94a174851e87c3d268c4021e03b75c1cb6df887727e32318cd1bf85b9164a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee7bf9f8d52d66428a2489e145eb0be7eee193d8c3ade4168b99695fd71776ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee7bf9f8d52d66428a2489e145eb0be7eee193d8c3ade4168b99695fd71776ed->enter($__internal_ee7bf9f8d52d66428a2489e145eb0be7eee193d8c3ade4168b99695fd71776ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 15
        echo "        <link rel=\"icon\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
  

  <body class=\"sidebar_main_open\">
    <!-- main header -->
    <header id=\"header_main\">
        <div class=\"header_main_content\">
            <nav class=\"uk-navbar\">
                <!-- main sidebar switch -->
                <a href=\"#\" id=\"sidebar_main_toggle\" class=\"sSwitch sSwitch_left\">
                    <span class=\"sSwitchIcon\"></span>
                </a>
                <!-- secondary sidebar switch -->
                <a href=\"#\" id=\"sidebar_secondary_toggle\" class=\"sSwitch sSwitch_right sidebar_secondary_check\">
                    <span class=\"sSwitchIcon\"></span>
                </a>
                <div class=\"uk-navbar-flip\">
                    <ul class=\"uk-navbar-nav user_actions\">
                        <li><a href=\"#\" id=\"main_search_btn\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE8B6;</i></a></li>
                        <li data-uk-dropdown=\"{mode:'click'}\" class=\"uk-hidden-small\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE0BE;</i><span class=\"uk-badge\">12</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-cyan\">yq</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Ipsum sed ipsam.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Cum architecto assumenda corporis aut qui eum occaecati in accusamus sint.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/avatars/avatar_07_tn.png"), "html", null, true);
        echo "\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Atque occaecati.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Et accusantium libero praesentium placeat quod perspiciatis et.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-light-green\">ao</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolor magnam iste.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Qui explicabo sit qui fugit corrupti sit in nesciunt.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"";
        // line 68
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/avatars/avatar_09_tn.png"), "html", null, true);
        echo "\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolore placeat.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Reprehenderit eum quam animi quia natus rem autem voluptatem voluptas earum.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/avatars/avatar_09_tn.png"), "html", null, true);
        echo "\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Voluptatum incidunt atque.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Eaque omnis nam eius quos sunt ut ipsa molestias.</span>
                                        </div>
                                    </li>
                                </ul>
                                <a href=\"page_mailbox.html\" class=\"md-btn md-btn-flat md-btn-flat-primary md-btn-block js-uk-prevent uk-margin-small-top\">Show All</a>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE7F4;</i><span class=\"uk-badge\">4</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-warning\">&#xE8B2;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Nesciunt natus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Alias sunt sint labore officiis ut.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-success\">&#xE88F;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Iusto reiciendis non.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Quaerat neque eum perspiciatis quasi officiis corporis exercitationem.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-danger\">&#xE001;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Enim suscipit.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Ea non omnis at consequatur.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-primary\">&#xE8FD;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Ea necessitatibus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Voluptatibus reiciendis quasi est enim aut et in error.</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_image\"><img class=\"md-user-image\" src=\"";
        // line 132
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/template/assets/img/avatars/avatar_11_tn.png"), "html", null, true);
        echo "\" alt=\"\"/></a>
                            <div class=\"uk-dropdown uk-dropdown-small uk-dropdown-flip\">
                                <ul class=\"uk-nav js-uk-prevent\">
                                   
                                    <li><a href=\"";
        // line 136
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("Logout");
        echo "\">Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class=\"header_main_search_form\">
            <i class=\"md-icon header_main_search_close material-icons\">&#xE5CD;</i>
            <form class=\"uk-form\">
                <input type=\"text\" class=\"header_main_search_input\" />
                <button class=\"header_main_search_btn uk-button-link\"><i class=\"md-icon material-icons\">&#xE8B6;</i></button>
            </form>
        </div>
    </header><!-- main header end -->

    <!-- main sidebar -->
    <aside id=\"sidebar_main\">
        <a href=\"#\" class=\"uk-close sidebar_main_close_button\"></a>
        <div class=\"sidebar_main_header\" style=\" height: 130px; \">
            <div class=\"sidebar_logo\" style=\"
    height: 130px;
\"><a href=\"index.html\"><img src=\"";
        // line 159
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/img/logo.png"), "html", null, true);
        echo "\" alt=\"\" height=\"130\" width=\"130\" style=\" margin: 14px; \"/></a></div>
            
        </div>
        <div class=\"menu_section\">
            <ul>
              
                <li>
                    <a href=\"#\">
                        <span class=\"menu_icon uk-icon-list-alt\"></span>
                        Livre
                    </a>
                    <ul>
                        <li><a href=\"";
        // line 171
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_new");
        echo "\">Ajout livre</a></li>
                        <li><a href=\"";
        // line 172
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_index");
        echo "\">Consulter les livres</a></li>
                  
                    </ul>
                </li>
                                
                <li>
                    <a href=\"#\">
                        <span class=\"menu_icon uk-icon-newspaper-o\"></span>
                        Catégories
                    </a>
                    <ul>
                         <li><a href=\"";
        // line 183
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_new");
        echo "\">Ajout Catégorie</a></li>
                        <li><a href=\"";
        // line 184
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">Consulter les Catégories</a></li>
                    </ul>
                </li>
                
               
            </ul>
        </div>
    </aside><!-- main sidebar end -->

    <div id=\"page_content\">
        <div id=\"page_content_inner\">

        
        


        ";
        // line 200
        $this->displayBlock('body', $context, $blocks);
        // line 203
        echo "







            
                
            </div>

        </div>
    </div>


<style type=\"text/css\">
    

    #acme_bibliobundle_livre_date_year{
 width: 10%;
 float: left;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


   #acme_bibliobundle_livre_date_month {
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


    #acme_bibliobundle_livre_date_day{
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }
</style>





    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
 

        ";
        // line 297
        $this->displayBlock('javascripts', $context, $blocks);
        // line 310
        echo "    </body>
</html>
";
        
        $__internal_ee7bf9f8d52d66428a2489e145eb0be7eee193d8c3ade4168b99695fd71776ed->leave($__internal_ee7bf9f8d52d66428a2489e145eb0be7eee193d8c3ade4168b99695fd71776ed_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_8ecbd73fa9530f2cd46c97a90dd56dd3265571c4693d8bc631739ec3c66f7901 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ecbd73fa9530f2cd46c97a90dd56dd3265571c4693d8bc631739ec3c66f7901->enter($__internal_8ecbd73fa9530f2cd46c97a90dd56dd3265571c4693d8bc631739ec3c66f7901_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_8ecbd73fa9530f2cd46c97a90dd56dd3265571c4693d8bc631739ec3c66f7901->leave($__internal_8ecbd73fa9530f2cd46c97a90dd56dd3265571c4693d8bc631739ec3c66f7901_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_31ae6114c7ebe7a89f842a0848bca600f9ea432863d49a96fc2068b2d5827312 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31ae6114c7ebe7a89f842a0848bca600f9ea432863d49a96fc2068b2d5827312->enter($__internal_31ae6114c7ebe7a89f842a0848bca600f9ea432863d49a96fc2068b2d5827312_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "

 

     <link  rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/bower_components/uikit/css/uikit.almost-flat.min.css"), "html", null, true);
        echo "\" />
     <link  rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/css/main.min.css"), "html", null, true);
        echo "\" />
     <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/icons/flags/flags.min.css"), "html", null, true);
        echo "\" /> 
        ";
        
        $__internal_31ae6114c7ebe7a89f842a0848bca600f9ea432863d49a96fc2068b2d5827312->leave($__internal_31ae6114c7ebe7a89f842a0848bca600f9ea432863d49a96fc2068b2d5827312_prof);

    }

    // line 200
    public function block_body($context, array $blocks = array())
    {
        $__internal_764d38dbcbe75feda9c26c086c317c0a1411ac9a50ace0aab81b2efa4773aecb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_764d38dbcbe75feda9c26c086c317c0a1411ac9a50ace0aab81b2efa4773aecb->enter($__internal_764d38dbcbe75feda9c26c086c317c0a1411ac9a50ace0aab81b2efa4773aecb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 201
        echo " 
        ";
        
        $__internal_764d38dbcbe75feda9c26c086c317c0a1411ac9a50ace0aab81b2efa4773aecb->leave($__internal_764d38dbcbe75feda9c26c086c317c0a1411ac9a50ace0aab81b2efa4773aecb_prof);

    }

    // line 297
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_7159eabc64a50f8d280ae047180d5a92f414495faae402bcf55a69468a83f548 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7159eabc64a50f8d280ae047180d5a92f414495faae402bcf55a69468a83f548->enter($__internal_7159eabc64a50f8d280ae047180d5a92f414495faae402bcf55a69468a83f548_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 298
        echo "   <script   type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/bower_components/moment/min/moment.min.js"), "html", null, true);
        echo "\" ></script>
  <script  type=\"text/javascript\" src=\"";
        // line 299
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/common.min.js"), "html", null, true);
        echo "\"></script>
 <script   type=\"text/javascript\" src=\"";
        // line 300
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/uikit_custom.min.js"), "html", null, true);
        echo "\" ></script>
 <script   type=\"text/javascript\" src=\"";
        // line 301
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/altair_admin_common.min.js"), "html", null, true);
        echo "\" ></script>
    <!-- enable hires images -->
    <script>
        \$(function() {
            altair_helpers.retina_images();
        });
    </script>

        ";
        
        $__internal_7159eabc64a50f8d280ae047180d5a92f414495faae402bcf55a69468a83f548->leave($__internal_7159eabc64a50f8d280ae047180d5a92f414495faae402bcf55a69468a83f548_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  440 => 301,  436 => 300,  432 => 299,  427 => 298,  421 => 297,  413 => 201,  407 => 200,  398 => 13,  394 => 12,  390 => 11,  384 => 7,  378 => 6,  366 => 5,  357 => 310,  355 => 297,  259 => 203,  257 => 200,  238 => 184,  234 => 183,  220 => 172,  216 => 171,  201 => 159,  175 => 136,  168 => 132,  110 => 77,  98 => 68,  77 => 50,  38 => 15,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}


 

     <link  rel=\"stylesheet\" href=\"{{ asset('template/bower_components/uikit/css/uikit.almost-flat.min.css') }}\" />
     <link  rel=\"stylesheet\" href=\"{{ asset('template/assets/css/main.min.css') }}\" />
     <link rel=\"stylesheet\" href=\"{{ asset('template/assets/icons/flags/flags.min.css') }}\" /> 
        {% endblock %}
        <link rel=\"icon\" type=\"text/css\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
  

  <body class=\"sidebar_main_open\">
    <!-- main header -->
    <header id=\"header_main\">
        <div class=\"header_main_content\">
            <nav class=\"uk-navbar\">
                <!-- main sidebar switch -->
                <a href=\"#\" id=\"sidebar_main_toggle\" class=\"sSwitch sSwitch_left\">
                    <span class=\"sSwitchIcon\"></span>
                </a>
                <!-- secondary sidebar switch -->
                <a href=\"#\" id=\"sidebar_secondary_toggle\" class=\"sSwitch sSwitch_right sidebar_secondary_check\">
                    <span class=\"sSwitchIcon\"></span>
                </a>
                <div class=\"uk-navbar-flip\">
                    <ul class=\"uk-navbar-nav user_actions\">
                        <li><a href=\"#\" id=\"main_search_btn\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE8B6;</i></a></li>
                        <li data-uk-dropdown=\"{mode:'click'}\" class=\"uk-hidden-small\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE0BE;</i><span class=\"uk-badge\">12</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-cyan\">yq</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Ipsum sed ipsam.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Cum architecto assumenda corporis aut qui eum occaecati in accusamus sint.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"{{ asset('template/assets/img/avatars/avatar_07_tn.png')}}\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Atque occaecati.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Et accusantium libero praesentium placeat quod perspiciatis et.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <span class=\"md-user-letters md-bg-light-green\">ao</span>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolor magnam iste.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Qui explicabo sit qui fugit corrupti sit in nesciunt.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"{{ asset('template/assets/img/avatars/avatar_09_tn.png') }}\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Dolore placeat.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Reprehenderit eum quam animi quia natus rem autem voluptatem voluptas earum.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <img class=\"md-user-image md-list-addon-avatar\" src=\"{{ asset('template/assets/img/avatars/avatar_09_tn.png') }}\" alt=\"\"/>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\"><a href=\"pages_mailbox.html\">Voluptatum incidunt atque.</a></span>
                                            <span class=\"uk-text-small uk-text-muted\">Eaque omnis nam eius quos sunt ut ipsa molestias.</span>
                                        </div>
                                    </li>
                                </ul>
                                <a href=\"page_mailbox.html\" class=\"md-btn md-btn-flat md-btn-flat-primary md-btn-block js-uk-prevent uk-margin-small-top\">Show All</a>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_icon\"><i class=\"material-icons md-24 md-light\">&#xE7F4;</i><span class=\"uk-badge\">4</span></a>
                            <div class=\"uk-dropdown uk-dropdown-xlarge uk-dropdown-flip uk-dropdown-scrollable\">
                                <ul class=\"md-list md-list-addon\">
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-warning\">&#xE8B2;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Nesciunt natus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Alias sunt sint labore officiis ut.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-success\">&#xE88F;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Iusto reiciendis non.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Quaerat neque eum perspiciatis quasi officiis corporis exercitationem.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-danger\">&#xE001;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Enim suscipit.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Ea non omnis at consequatur.</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class=\"md-list-addon-element\">
                                            <i class=\"md-list-addon-icon material-icons uk-text-primary\">&#xE8FD;</i>
                                        </div>
                                        <div class=\"md-list-content\">
                                            <span class=\"md-list-heading\">Ea necessitatibus.</span>
                                            <span class=\"uk-text-small uk-text-muted uk-text-truncate\">Voluptatibus reiciendis quasi est enim aut et in error.</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li data-uk-dropdown=\"{mode:'click'}\">
                            <a href=\"#\" class=\"user_action_image\"><img class=\"md-user-image\" src=\"{{ asset('/template/assets/img/avatars/avatar_11_tn.png') }}\" alt=\"\"/></a>
                            <div class=\"uk-dropdown uk-dropdown-small uk-dropdown-flip\">
                                <ul class=\"uk-nav js-uk-prevent\">
                                   
                                    <li><a href=\"{{ path('Logout') }}\">Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class=\"header_main_search_form\">
            <i class=\"md-icon header_main_search_close material-icons\">&#xE5CD;</i>
            <form class=\"uk-form\">
                <input type=\"text\" class=\"header_main_search_input\" />
                <button class=\"header_main_search_btn uk-button-link\"><i class=\"md-icon material-icons\">&#xE8B6;</i></button>
            </form>
        </div>
    </header><!-- main header end -->

    <!-- main sidebar -->
    <aside id=\"sidebar_main\">
        <a href=\"#\" class=\"uk-close sidebar_main_close_button\"></a>
        <div class=\"sidebar_main_header\" style=\" height: 130px; \">
            <div class=\"sidebar_logo\" style=\"
    height: 130px;
\"><a href=\"index.html\"><img src=\"{{ asset('template/assets/img/logo.png') }}\" alt=\"\" height=\"130\" width=\"130\" style=\" margin: 14px; \"/></a></div>
            
        </div>
        <div class=\"menu_section\">
            <ul>
              
                <li>
                    <a href=\"#\">
                        <span class=\"menu_icon uk-icon-list-alt\"></span>
                        Livre
                    </a>
                    <ul>
                        <li><a href=\"{{ path('livre_new') }}\">Ajout livre</a></li>
                        <li><a href=\"{{ path('livre_index') }}\">Consulter les livres</a></li>
                  
                    </ul>
                </li>
                                
                <li>
                    <a href=\"#\">
                        <span class=\"menu_icon uk-icon-newspaper-o\"></span>
                        Catégories
                    </a>
                    <ul>
                         <li><a href=\"{{ path('category_new') }}\">Ajout Catégorie</a></li>
                        <li><a href=\"{{ path('category_index') }}\">Consulter les Catégories</a></li>
                    </ul>
                </li>
                
               
            </ul>
        </div>
    </aside><!-- main sidebar end -->

    <div id=\"page_content\">
        <div id=\"page_content_inner\">

        
        


        {% block body %}
 
        {% endblock %}








            
                
            </div>

        </div>
    </div>


<style type=\"text/css\">
    

    #acme_bibliobundle_livre_date_year{
 width: 10%;
 float: left;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


   #acme_bibliobundle_livre_date_month {
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }


    #acme_bibliobundle_livre_date_day{
 width: 10%;
 float: left;
 margin-left: 10px;
            border-radius: 0;
    border-width: 0 0 1px;
    border-style: solid;
    border-color: rgba(0,0,0,.12);
    font: 400 15px/18px Roboto,sans-serif;
    box-shadow: inset 0 -1px 0 transparent;
    box-sizing: border-box;
    padding: 12px 4px;
    background: 0 0;
     display: block;
    }
</style>





    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
 

        {% block javascripts %}
   <script   type=\"text/javascript\" src=\"{{ asset('template/bower_components/moment/min/moment.min.js') }}\" ></script>
  <script  type=\"text/javascript\" src=\"{{ asset('template/assets/js/common.min.js') }}\"></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/uikit_custom.min.js') }}\" ></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/altair_admin_common.min.js') }}\" ></script>
    <!-- enable hires images -->
    <script>
        \$(function() {
            altair_helpers.retina_images();
        });
    </script>

        {% endblock %}
    </body>
</html>
", "::base.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app/Resources\\views/base.html.twig");
    }
}

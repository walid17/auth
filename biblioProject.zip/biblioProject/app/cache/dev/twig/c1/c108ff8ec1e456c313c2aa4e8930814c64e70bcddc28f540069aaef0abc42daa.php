<?php

/* livre/index.html.twig */
class __TwigTemplate_ee34d07f8a03c46b0a6b6fdd77eebec673e846fd4cc40ad283818485dcdb7b62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "livre/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e9bd665cb4e20f3e4ab031d79b4e6e8e303a67894d210f69aec3ceb45eed4942 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9bd665cb4e20f3e4ab031d79b4e6e8e303a67894d210f69aec3ceb45eed4942->enter($__internal_e9bd665cb4e20f3e4ab031d79b4e6e8e303a67894d210f69aec3ceb45eed4942_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "livre/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e9bd665cb4e20f3e4ab031d79b4e6e8e303a67894d210f69aec3ceb45eed4942->leave($__internal_e9bd665cb4e20f3e4ab031d79b4e6e8e303a67894d210f69aec3ceb45eed4942_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_277833baf815f00fb16779eb3c448a51432576d67685ee503c664977ae1ced88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_277833baf815f00fb16779eb3c448a51432576d67685ee503c664977ae1ced88->enter($__internal_277833baf815f00fb16779eb3c448a51432576d67685ee503c664977ae1ced88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

  








<h4 class=\"heading_a uk-margin-bottom\">Livres list</h4>
<div class=\"md-card uk-margin-medium-bottom\">
    <div class=\"md-card-content\">
        <div class=\"uk-overflow-container\">
            <table class=\"uk-table uk-table-striped\">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Acteur</th>
                    <th>Titre</th>
                    <th>Photo</th>
                    <th>Pdf</th>
                    <th>Nbrpage</th>
                    <th>Nbrdownload</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>


                 ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["livres"]) ? $context["livres"] : $this->getContext($context, "livres")));
        foreach ($context['_seq'] as $context["_key"] => $context["livre"]) {
            // line 37
            echo "                    <tr>
                        <td><a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_show", array("id" => $this->getAttribute($context["livre"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "id", array()), "html", null, true);
            echo "</a></td>
                        <td>";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "acteur", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "titre", array()), "html", null, true);
            echo "</td>
                        
                          <td>

                            <a href='/images/pdfs/";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "imageNam", array()), "html", null, true);
            echo "' download>
                              <img src=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/template/image/pdf.png"), "html", null, true);
            echo "\" style=\"width: 80px;\">
                            </a>

                            </td>
                             <td>

                            <a href=\"";
            // line 51
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/images/products/" . $this->getAttribute($context["livre"], "imageName", array()))), "html", null, true);
            echo "\">
                             
                                <img src=\"";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("/images/products/" . $this->getAttribute($context["livre"], "imageName", array()))), "html", null, true);
            echo "\" style=\"width: 80px;\">
                  
                            </a>

                          </td>
                       
                        <td>";
            // line 59
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "nbrPage", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 60
            echo twig_escape_filter($this->env, $this->getAttribute($context["livre"], "nbrDownload", array()), "html", null, true);
            echo "</td>
                        <td>";
            // line 61
            if ($this->getAttribute($context["livre"], "date", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["livre"], "date", array()), "Y-m-d"), "html", null, true);
            }
            echo "</td>
                        <td>
                          

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\" width: 45px; height: 45px; float: left;\" href=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_show", array("id" => $this->getAttribute($context["livre"], "id", array()))), "html", null, true);
            echo "\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">remove_red_eye</i>
                                    </a>
  

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\"    background: #4CAF50; width: 45px; height: 45px;float: left; margin-left: 5px; \"  href=\"";
            // line 70
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_edit", array("id" => $this->getAttribute($context["livre"], "id", array()))), "html", null, true);
            echo "\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">edit</i>
                                    </a>
 
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['livre'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 77
        echo "              
                </tbody>
            </table>
        </div>
    </div>
</div>





    <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 89
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("livre_new");
        echo "\">
                        <i class=\"material-icons\">add</i>
                        </a>
                     
                    </div>
 
";
        
        $__internal_277833baf815f00fb16779eb3c448a51432576d67685ee503c664977ae1ced88->leave($__internal_277833baf815f00fb16779eb3c448a51432576d67685ee503c664977ae1ced88_prof);

    }

    public function getTemplateName()
    {
        return "livre/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 89,  163 => 77,  150 => 70,  142 => 65,  133 => 61,  129 => 60,  125 => 59,  116 => 53,  111 => 51,  102 => 45,  98 => 44,  91 => 40,  87 => 39,  81 => 38,  78 => 37,  74 => 36,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}


  








<h4 class=\"heading_a uk-margin-bottom\">Livres list</h4>
<div class=\"md-card uk-margin-medium-bottom\">
    <div class=\"md-card-content\">
        <div class=\"uk-overflow-container\">
            <table class=\"uk-table uk-table-striped\">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Acteur</th>
                    <th>Titre</th>
                    <th>Photo</th>
                    <th>Pdf</th>
                    <th>Nbrpage</th>
                    <th>Nbrdownload</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>


                 {% for livre in livres %}
                    <tr>
                        <td><a href=\"{{ path('livre_show', { 'id': livre.id }) }}\">{{ livre.id }}</a></td>
                        <td>{{ livre.acteur }}</td>
                        <td>{{ livre.titre }}</td>
                        
                          <td>

                            <a href='/images/pdfs/{{ livre.imageNam }}' download>
                              <img src=\"{{ asset('/template/image/pdf.png') }}\" style=\"width: 80px;\">
                            </a>

                            </td>
                             <td>

                            <a href=\"{{ asset(\"/images/products/\" ~ livre.imageName) }}\">
                             
                                <img src=\"{{ asset(\"/images/products/\" ~ livre.imageName) }}\" style=\"width: 80px;\">
                  
                            </a>

                          </td>
                       
                        <td>{{ livre.nbrPage }}</td>
                        <td>{{ livre.nbrDownload }}</td>
                        <td>{% if livre.date %}{{ livre.date|date('Y-m-d') }}{% endif %}</td>
                        <td>
                          

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\" width: 45px; height: 45px; float: left;\" href=\"{{ path('livre_show', { 'id': livre.id }) }}\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">remove_red_eye</i>
                                    </a>
  

                                <a class=\"md-fab md-fab-primary md-fab-actions\" style=\"    background: #4CAF50; width: 45px; height: 45px;float: left; margin-left: 5px; \"  href=\"{{ path('livre_edit', { 'id': livre.id }) }}\">
                                    <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">edit</i>
                                    </a>
 
                        </td>
                    </tr>
                {% endfor %}
              
                </tbody>
            </table>
        </div>
    </div>
</div>





    <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('livre_new') }}\">
                        <i class=\"material-icons\">add</i>
                        </a>
                     
                    </div>
 
{% endblock %}
", "livre/index.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app\\Resources\\views\\livre\\index.html.twig");
    }
}

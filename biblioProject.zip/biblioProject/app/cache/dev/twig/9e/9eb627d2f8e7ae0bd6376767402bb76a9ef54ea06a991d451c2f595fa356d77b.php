<?php

/* :category:index.html.twig */
class __TwigTemplate_df224140c3cd67102987614a9f64a6d632413d61cefd51d36ab5f9c2bdc733b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67182f56e112141e94fea6bea928468f54d7974622f4fe7d4e0a6afe5f1af852 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67182f56e112141e94fea6bea928468f54d7974622f4fe7d4e0a6afe5f1af852->enter($__internal_67182f56e112141e94fea6bea928468f54d7974622f4fe7d4e0a6afe5f1af852_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_67182f56e112141e94fea6bea928468f54d7974622f4fe7d4e0a6afe5f1af852->leave($__internal_67182f56e112141e94fea6bea928468f54d7974622f4fe7d4e0a6afe5f1af852_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_198cd1eb0bc3321476d472fa4585ad4c3e75b84a046c9a115abf41d645d9aaca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_198cd1eb0bc3321476d472fa4585ad4c3e75b84a046c9a115abf41d645d9aaca->enter($__internal_198cd1eb0bc3321476d472fa4585ad4c3e75b84a046c9a115abf41d645d9aaca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

<h4 class=\"heading_a uk-margin-bottom\">Categories list</h4>
<div class=\"md-card uk-margin-medium-bottom\">
    <div class=\"md-card-content\">
        <div class=\"uk-overflow-container\">
            <table class=\"uk-table uk-table-striped\">
                <thead>
                <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Description</th>
                <th>Type</th>
                <th>Actions</th>
             </tr>
                </thead>
                <tbody>
 
     ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 23
            echo "            <tr>
                <td><a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "description", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "type", array()), "html", null, true);
            echo "</td>


                   <td>
                          

                    <a class=\"md-fab md-fab-primary md-fab-actions\" style=\" width: 45px; height: 45px; float: left;\" href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">
                        <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">remove_red_eye</i>
                        </a>


                    <a class=\"md-fab md-fab-primary md-fab-actions\" style=\"    background: #4CAF50; width: 45px; height: 45px;float: left; margin-left: 5px; \"  href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_edit", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">
                        <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">edit</i>
                        </a>

            </td>


                
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "       </tbody>
            </table>
        </div>
    </div>
</div>





    <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_new");
        echo "\">
                        <i class=\"material-icons\">add</i>
                        </a>
                     
                    </div>



 
";
        
        $__internal_198cd1eb0bc3321476d472fa4585ad4c3e75b84a046c9a115abf41d645d9aaca->leave($__internal_198cd1eb0bc3321476d472fa4585ad4c3e75b84a046c9a115abf41d645d9aaca_prof);

    }

    public function getTemplateName()
    {
        return ":category:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 59,  114 => 48,  98 => 38,  90 => 33,  81 => 27,  77 => 26,  73 => 25,  67 => 24,  64 => 23,  60 => 22,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}


<h4 class=\"heading_a uk-margin-bottom\">Categories list</h4>
<div class=\"md-card uk-margin-medium-bottom\">
    <div class=\"md-card-content\">
        <div class=\"uk-overflow-container\">
            <table class=\"uk-table uk-table-striped\">
                <thead>
                <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Description</th>
                <th>Type</th>
                <th>Actions</th>
             </tr>
                </thead>
                <tbody>
 
     {% for category in categories %}
            <tr>
                <td><a href=\"{{ path('category_show', { 'id': category.id }) }}\">{{ category.id }}</a></td>
                <td>{{ category.name }}</td>
                <td>{{ category.description }}</td>
                <td>{{ category.type }}</td>


                   <td>
                          

                    <a class=\"md-fab md-fab-primary md-fab-actions\" style=\" width: 45px; height: 45px; float: left;\" href=\"{{ path('category_show', { 'id': category.id }) }}\">
                        <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">remove_red_eye</i>
                        </a>


                    <a class=\"md-fab md-fab-primary md-fab-actions\" style=\"    background: #4CAF50; width: 45px; height: 45px;float: left; margin-left: 5px; \"  href=\"{{ path('category_edit', { 'id': category.id }) }}\">
                        <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">edit</i>
                        </a>

            </td>


                
            </tr>
        {% endfor %}
       </tbody>
            </table>
        </div>
    </div>
</div>





    <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('category_new') }}\">
                        <i class=\"material-icons\">add</i>
                        </a>
                     
                    </div>



 
{% endblock %}
", ":category:index.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app/Resources\\views/category/index.html.twig");
    }
}

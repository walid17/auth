<?php

/* category/new.html.twig */
class __TwigTemplate_529d4c0ae22b9c6112d680a9a1c444bf3d884dc5ae39824001e3b1676b37fe5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f4a23796b8831c49d2eb2337374920875da47b8782ff29518503ce117067cd1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4a23796b8831c49d2eb2337374920875da47b8782ff29518503ce117067cd1a->enter($__internal_f4a23796b8831c49d2eb2337374920875da47b8782ff29518503ce117067cd1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f4a23796b8831c49d2eb2337374920875da47b8782ff29518503ce117067cd1a->leave($__internal_f4a23796b8831c49d2eb2337374920875da47b8782ff29518503ce117067cd1a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_625cdf7fc6ad549dae708c3831ef510a33014542998360afffa2d5234c5d2dca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_625cdf7fc6ad549dae708c3831ef510a33014542998360afffa2d5234c5d2dca->enter($__internal_625cdf7fc6ad549dae708c3831ef510a33014542998360afffa2d5234c5d2dca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "


<div class=\"md-card\">
                <div class=\"md-card-content\">


    <h3 class=\"heading_a\">Category creation</h3>

   


                    ";
        // line 16
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Name</label>
                                ";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Description</label>
                                ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Type</label>
                                ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "type", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>

 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Create\" />
                          </div>  

                                ";
        // line 45
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
 







                </div>
            </div>



            <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>

";
        
        $__internal_625cdf7fc6ad549dae708c3831ef510a33014542998360afffa2d5234c5d2dca->leave($__internal_625cdf7fc6ad549dae708c3831ef510a33014542998360afffa2d5234c5d2dca_prof);

    }

    public function getTemplateName()
    {
        return "category/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 60,  95 => 45,  82 => 35,  71 => 27,  61 => 20,  54 => 16,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}



<div class=\"md-card\">
                <div class=\"md-card-content\">


    <h3 class=\"heading_a\">Category creation</h3>

   


                    {{ form_start(form) }}
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Name</label>
                                {{ form_widget(form.name,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Description</label>
                                {{ form_widget(form.description,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Type</label>
                                {{ form_widget(form.type,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>

 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Create\" />
                          </div>  

                                {{ form_end(form) }}
 







                </div>
            </div>



            <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('category_index') }}\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>

{% endblock %}


", "category/new.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app\\Resources\\views\\category\\new.html.twig");
    }
}

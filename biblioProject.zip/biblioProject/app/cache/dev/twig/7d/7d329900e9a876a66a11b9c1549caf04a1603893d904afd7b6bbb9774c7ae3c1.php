<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_e8ea3aebead22083fed264c3ef4461e1155f4e630a12cfb58679c469ded0231c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5aa50459800f80ae59aafcdc4cad22a9ff03b6b19e74f16d26437ed4bac2e1ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5aa50459800f80ae59aafcdc4cad22a9ff03b6b19e74f16d26437ed4bac2e1ee->enter($__internal_5aa50459800f80ae59aafcdc4cad22a9ff03b6b19e74f16d26437ed4bac2e1ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_5aa50459800f80ae59aafcdc4cad22a9ff03b6b19e74f16d26437ed4bac2e1ee->leave($__internal_5aa50459800f80ae59aafcdc4cad22a9ff03b6b19e74f16d26437ed4bac2e1ee_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}

<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_ce3033c65f2f90f75e595b90c5a8b69901055a4f69f911d3a97abcbcd8ba497f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e950379175ec6bd4a832243181bcbca325a6c16cf351a73aa67ae55ad69c6369 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e950379175ec6bd4a832243181bcbca325a6c16cf351a73aa67ae55ad69c6369->enter($__internal_e950379175ec6bd4a832243181bcbca325a6c16cf351a73aa67ae55ad69c6369_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle::layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />



      ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 15
        echo "


    </head>
    <body class=\"login_page\">


                          <div class=\"uk-width-medium-1-4\" id=\"zoneload\" style=\"display: none;margin: 0 auto;width: 4%;z-index: 100000;position: relative;\" >
                            <div class=\"md-preloader\"><svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" height=\"48\" width=\"48\" viewbox=\"0 0 75 75\"><circle cx=\"37.5\" cy=\"37.5\" r=\"33.5\" stroke-width=\"4\"/></svg></div>
                        </div>


     <!--   <div>
            ";
        // line 28
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 29
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array())), "FOSUserBundle"), "html", null, true);
            echo " |
                <a href=\"";
            // line 30
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                    ";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
                </a>
            ";
        } else {
            // line 34
            echo "                <a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
            ";
        }
        // line 36
        echo "        </div>

        -->

        ";
        // line 40
        if ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "hasPreviousSession", array())) {
            // line 41
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 42
                echo "                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 43
                    echo "                    <div class=\"flash-";
                    echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                    echo "\">
                        ";
                    // line 44
                    echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                    echo "
                    </div>
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 47
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 48
            echo "        ";
        }
        // line 49
        echo "
        <div>
            ";
        // line 51
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 53
        echo "        </div>
    </body>




        ";
        // line 59
        $this->displayBlock('javascripts', $context, $blocks);
        // line 102
        echo "


</html>
";
        
        $__internal_e950379175ec6bd4a832243181bcbca325a6c16cf351a73aa67ae55ad69c6369->leave($__internal_e950379175ec6bd4a832243181bcbca325a6c16cf351a73aa67ae55ad69c6369_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d4840da4efdb0640ab019c0076a1e93653789d519367fd53623433db9ef6e37c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4840da4efdb0640ab019c0076a1e93653789d519367fd53623433db9ef6e37c->enter($__internal_d4840da4efdb0640ab019c0076a1e93653789d519367fd53623433db9ef6e37c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo " 

     <link  rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/css/login_page.min.css"), "html", null, true);
        echo "\" />
     <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("http://fonts.googleapis.com/css?family=Roboto:300,400,500"), "html", null, true);
        echo "\" />
     <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/bower_components/uikit/css/uikit.almost-flat.min.css"), "html", null, true);
        echo "\" />
        ";
        
        $__internal_d4840da4efdb0640ab019c0076a1e93653789d519367fd53623433db9ef6e37c->leave($__internal_d4840da4efdb0640ab019c0076a1e93653789d519367fd53623433db9ef6e37c_prof);

    }

    // line 51
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_6dae3671c502b0fc8ad4a5a801a40013301a0b8f0de693385a7eed9531f1ad18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6dae3671c502b0fc8ad4a5a801a40013301a0b8f0de693385a7eed9531f1ad18->enter($__internal_6dae3671c502b0fc8ad4a5a801a40013301a0b8f0de693385a7eed9531f1ad18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 52
        echo "            ";
        
        $__internal_6dae3671c502b0fc8ad4a5a801a40013301a0b8f0de693385a7eed9531f1ad18->leave($__internal_6dae3671c502b0fc8ad4a5a801a40013301a0b8f0de693385a7eed9531f1ad18_prof);

    }

    // line 59
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_678acb4d82e12c58e88f8e0c8c36dc160b8080b2541f9b7ec179527a2c8ff06e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_678acb4d82e12c58e88f8e0c8c36dc160b8080b2541f9b7ec179527a2c8ff06e->enter($__internal_678acb4d82e12c58e88f8e0c8c36dc160b8080b2541f9b7ec179527a2c8ff06e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 60
        echo "
    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
  
  <script  type=\"text/javascript\" src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/pages/login_page.min.js"), "html", null, true);
        echo "\" ></script>
 <script   type=\"text/javascript\" src=\"";
        // line 82
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/altair_admin_common.min.js"), "html", null, true);
        echo "\" ></script>
 <script   type=\"text/javascript\" src=\"";
        // line 83
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/pages/login_page.min.js"), "html", null, true);
        echo "\" ></script>

 <script   type=\"text/javascript\" src=\"";
        // line 85
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("template/assets/js/pages/components_preloaders.min.js"), "html", null, true);
        echo "\" ></script>

 

    <!-- enable hires images -->
    <script>
       
function fnshowload(){
//alert(\"cc\");
   document.getElementById(\"zoneload\").style.display=\"block\";
}
        


    </script>

        ";
        
        $__internal_678acb4d82e12c58e88f8e0c8c36dc160b8080b2541f9b7ec179527a2c8ff06e->leave($__internal_678acb4d82e12c58e88f8e0c8c36dc160b8080b2541f9b7ec179527a2c8ff06e_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 85,  221 => 83,  217 => 82,  213 => 81,  190 => 60,  184 => 59,  177 => 52,  171 => 51,  162 => 13,  158 => 12,  154 => 11,  150 => 9,  144 => 8,  133 => 102,  131 => 59,  123 => 53,  121 => 51,  117 => 49,  114 => 48,  108 => 47,  99 => 44,  94 => 43,  89 => 42,  84 => 41,  82 => 40,  76 => 36,  68 => 34,  62 => 31,  58 => 30,  53 => 29,  51 => 28,  36 => 15,  34 => 8,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />



      {% block stylesheets %}
 

     <link  rel=\"stylesheet\" href=\"{{ asset('template/assets/css/login_page.min.css') }}\" />
     <link rel=\"stylesheet\" href=\"{{ asset('http://fonts.googleapis.com/css?family=Roboto:300,400,500') }}\" />
     <link rel=\"stylesheet\" href=\"{{ asset('template/bower_components/uikit/css/uikit.almost-flat.min.css') }}\" />
        {% endblock %}



    </head>
    <body class=\"login_page\">


                          <div class=\"uk-width-medium-1-4\" id=\"zoneload\" style=\"display: none;margin: 0 auto;width: 4%;z-index: 100000;position: relative;\" >
                            <div class=\"md-preloader\"><svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" height=\"48\" width=\"48\" viewbox=\"0 0 75 75\"><circle cx=\"37.5\" cy=\"37.5\" r=\"33.5\" stroke-width=\"4\"/></svg></div>
                        </div>


     <!--   <div>
            {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
                {{ 'layout.logged_in_as'|trans({'%username%': app.user.username}, 'FOSUserBundle') }} |
                <a href=\"{{ path('fos_user_security_logout') }}\">
                    {{ 'layout.logout'|trans({}, 'FOSUserBundle') }}
                </a>
            {% else %}
                <a href=\"{{ path('fos_user_security_login') }}\">{{ 'layout.login'|trans({}, 'FOSUserBundle') }}</a>
            {% endif %}
        </div>

        -->

        {% if app.request.hasPreviousSession %}
            {% for type, messages in app.session.flashbag.all() %}
                {% for message in messages %}
                    <div class=\"flash-{{ type }}\">
                        {{ message }}
                    </div>
                {% endfor %}
            {% endfor %}
        {% endif %}

        <div>
            {% block fos_user_content %}
            {% endblock fos_user_content %}
        </div>
    </body>




        {% block javascripts %}

    <script>
        WebFontConfig = {
            google: {
                families: [
                    'Source+Code+Pro:400,700:latin',
                    'Roboto:400,300,500,700,400italic:latin'
                ]
            }
        };
        (function() {
            var wf = document.createElement('script');
            wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
            '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
            wf.type = 'text/javascript';
            wf.async = 'true';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(wf, s);
        })();
    </script>
  
  <script  type=\"text/javascript\" src=\"{{ asset('template/assets/js/pages/login_page.min.js') }}\" ></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/altair_admin_common.min.js') }}\" ></script>
 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/pages/login_page.min.js') }}\" ></script>

 <script   type=\"text/javascript\" src=\"{{ asset('template/assets/js/pages/components_preloaders.min.js') }}\" ></script>

 

    <!-- enable hires images -->
    <script>
       
function fnshowload(){
//alert(\"cc\");
   document.getElementById(\"zoneload\").style.display=\"block\";
}
        


    </script>

        {% endblock %}



</html>
", "FOSUserBundle::layout.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\layout.html.twig");
    }
}

<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_9894144d71cf66868ca8939516d8a6107e567568d0f5328e417c950cfd414a3e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5d5aab2c48b0bf69c728c2bdaf9571928858ff3ab3c831b0938028a8abbf4b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5d5aab2c48b0bf69c728c2bdaf9571928858ff3ab3c831b0938028a8abbf4b9->enter($__internal_e5d5aab2c48b0bf69c728c2bdaf9571928858ff3ab3c831b0938028a8abbf4b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_e5d5aab2c48b0bf69c728c2bdaf9571928858ff3ab3c831b0938028a8abbf4b9->leave($__internal_e5d5aab2c48b0bf69c728c2bdaf9571928858ff3ab3c831b0938028a8abbf4b9_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}

<?php

/* @FOSUser/Group/new.html.twig */
class __TwigTemplate_bcad2976e7e00f7c93b44a43f6a95710ed4b85c50e082fc59aee7983f87cb5ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Group/new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec4dfcb37161c13899f410dddc7101cfcf89ce03d65714f4ed39d32a33e886e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec4dfcb37161c13899f410dddc7101cfcf89ce03d65714f4ed39d32a33e886e6->enter($__internal_ec4dfcb37161c13899f410dddc7101cfcf89ce03d65714f4ed39d32a33e886e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ec4dfcb37161c13899f410dddc7101cfcf89ce03d65714f4ed39d32a33e886e6->leave($__internal_ec4dfcb37161c13899f410dddc7101cfcf89ce03d65714f4ed39d32a33e886e6_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_723ff3475eb39ae9ae50790601e8bfdb6c43d0b70c9f0dce6ed247fc35ac49da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_723ff3475eb39ae9ae50790601e8bfdb6c43d0b70c9f0dce6ed247fc35ac49da->enter($__internal_723ff3475eb39ae9ae50790601e8bfdb6c43d0b70c9f0dce6ed247fc35ac49da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "@FOSUser/Group/new.html.twig", 4)->display($context);
        
        $__internal_723ff3475eb39ae9ae50790601e8bfdb6c43d0b70c9f0dce6ed247fc35ac49da->leave($__internal_723ff3475eb39ae9ae50790601e8bfdb6c43d0b70c9f0dce6ed247fc35ac49da_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Group:new_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Group/new.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Group\\new.html.twig");
    }
}

<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_2ebb3bfe971741c231fc87734a19b1aad1efee31c38707fa68c57c7046e3382c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4481088111416b37164d21ebf618fa0f5ace6ff9a127bba75f0c6a1c95f3f67c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4481088111416b37164d21ebf618fa0f5ace6ff9a127bba75f0c6a1c95f3f67c->enter($__internal_4481088111416b37164d21ebf618fa0f5ace6ff9a127bba75f0c6a1c95f3f67c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_4481088111416b37164d21ebf618fa0f5ace6ff9a127bba75f0c6a1c95f3f67c->leave($__internal_4481088111416b37164d21ebf618fa0f5ace6ff9a127bba75f0c6a1c95f3f67c_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_fd154ca534da9b5de83763b698ddc7238f33db80b88582dd75a3e9fc57eb5de8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd154ca534da9b5de83763b698ddc7238f33db80b88582dd75a3e9fc57eb5de8->enter($__internal_fd154ca534da9b5de83763b698ddc7238f33db80b88582dd75a3e9fc57eb5de8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_fd154ca534da9b5de83763b698ddc7238f33db80b88582dd75a3e9fc57eb5de8->leave($__internal_fd154ca534da9b5de83763b698ddc7238f33db80b88582dd75a3e9fc57eb5de8_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}

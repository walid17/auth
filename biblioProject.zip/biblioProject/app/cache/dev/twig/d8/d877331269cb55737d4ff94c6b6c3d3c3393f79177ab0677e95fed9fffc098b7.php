<?php

/* :category:new.html.twig */
class __TwigTemplate_730c50107e4e0dc7bbe36a2fd4ad9691cf589856604275f0b5265a73e6bf71b8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bfd06a2abf6eae9a56dde3947851aa674ffa889adeb3bfe56f107dce1499f19a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfd06a2abf6eae9a56dde3947851aa674ffa889adeb3bfe56f107dce1499f19a->enter($__internal_bfd06a2abf6eae9a56dde3947851aa674ffa889adeb3bfe56f107dce1499f19a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bfd06a2abf6eae9a56dde3947851aa674ffa889adeb3bfe56f107dce1499f19a->leave($__internal_bfd06a2abf6eae9a56dde3947851aa674ffa889adeb3bfe56f107dce1499f19a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d95b5bbd2d2f6c188620e432f102538e3baca5fac2170b156b0952691a8b8b5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d95b5bbd2d2f6c188620e432f102538e3baca5fac2170b156b0952691a8b8b5c->enter($__internal_d95b5bbd2d2f6c188620e432f102538e3baca5fac2170b156b0952691a8b8b5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "


<div class=\"md-card\">
                <div class=\"md-card-content\">


    <h3 class=\"heading_a\">Category creation</h3>

   


                    ";
        // line 16
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Name</label>
                                ";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Description</label>
                                ";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Type</label>
                                ";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "type", array()), 'widget', array("attr" => array("class" => "md-input")));
        echo "
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>

 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Create\" />
                          </div>  

                                ";
        // line 45
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
 







                </div>
            </div>



            <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>

";
        
        $__internal_d95b5bbd2d2f6c188620e432f102538e3baca5fac2170b156b0952691a8b8b5c->leave($__internal_d95b5bbd2d2f6c188620e432f102538e3baca5fac2170b156b0952691a8b8b5c_prof);

    }

    public function getTemplateName()
    {
        return ":category:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 60,  95 => 45,  82 => 35,  71 => 27,  61 => 20,  54 => 16,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}



<div class=\"md-card\">
                <div class=\"md-card-content\">


    <h3 class=\"heading_a\">Category creation</h3>

   


                    {{ form_start(form) }}
    
                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Name</label>
                                {{ form_widget(form.name,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div> 

                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Description</label>
                                {{ form_widget(form.description,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>


                             <div class=\"uk-form-row\">
                                <div class=\"md-input-wrapper\"><label>Type</label>
                                {{ form_widget(form.type,{'attr' : { 'class' : 'md-input' }}) }}
                                <span class=\"md-input-bar\"></span></div>
                                 
                            </div>

 
                             <div class=\"uk-form-row\" style=\" margin-left: 90%;\" >
                                <input type=\"submit\"  class=\"md-btn md-btn-primary\" value=\"Create\" />
                          </div>  

                                {{ form_end(form) }}
 







                </div>
            </div>



            <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"{{ path('category_index') }}\">
                        <i class=\"material-icons\">list</i>
                        </a>
                     
                    </div>

{% endblock %}


", ":category:new.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app/Resources\\views/category/new.html.twig");
    }
}

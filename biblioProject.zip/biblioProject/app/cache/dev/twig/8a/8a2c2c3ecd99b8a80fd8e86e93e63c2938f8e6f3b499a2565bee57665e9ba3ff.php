<?php

/* @FOSUser/Profile/edit.html.twig */
class __TwigTemplate_abc9a3b3ac3b9b37a9bfa07acb28bbadc01707648b01a4ad1e862ebcd544a4a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Profile/edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49c4fcc76a43651c1a82714fe2ceae5339bca4f566a65fc790cb969fbe04620c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49c4fcc76a43651c1a82714fe2ceae5339bca4f566a65fc790cb969fbe04620c->enter($__internal_49c4fcc76a43651c1a82714fe2ceae5339bca4f566a65fc790cb969fbe04620c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Profile/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_49c4fcc76a43651c1a82714fe2ceae5339bca4f566a65fc790cb969fbe04620c->leave($__internal_49c4fcc76a43651c1a82714fe2ceae5339bca4f566a65fc790cb969fbe04620c_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c3a51a1bbb14a01b4659ee124ad55a5b1c050d3182a40ec3e5b76842c7f03c32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3a51a1bbb14a01b4659ee124ad55a5b1c050d3182a40ec3e5b76842c7f03c32->enter($__internal_c3a51a1bbb14a01b4659ee124ad55a5b1c050d3182a40ec3e5b76842c7f03c32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "@FOSUser/Profile/edit.html.twig", 4)->display($context);
        
        $__internal_c3a51a1bbb14a01b4659ee124ad55a5b1c050d3182a40ec3e5b76842c7f03c32->leave($__internal_c3a51a1bbb14a01b4659ee124ad55a5b1c050d3182a40ec3e5b76842c7f03c32_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Profile/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Profile:edit_content.html.twig\" %}
{% endblock fos_user_content %}
", "@FOSUser/Profile/edit.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\Profile\\edit.html.twig");
    }
}

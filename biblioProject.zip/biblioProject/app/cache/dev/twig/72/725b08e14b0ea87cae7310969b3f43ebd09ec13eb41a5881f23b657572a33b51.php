<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_cb2a477af94e92af6d879de71d848b78ee41825e232ac225eabcd8e2d8c12501 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c4469e7f9d0d38573700b40b6703fb54508ca924fe78c34b3f38a57df77b4eaa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4469e7f9d0d38573700b40b6703fb54508ca924fe78c34b3f38a57df77b4eaa->enter($__internal_c4469e7f9d0d38573700b40b6703fb54508ca924fe78c34b3f38a57df77b4eaa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c4469e7f9d0d38573700b40b6703fb54508ca924fe78c34b3f38a57df77b4eaa->leave($__internal_c4469e7f9d0d38573700b40b6703fb54508ca924fe78c34b3f38a57df77b4eaa_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_ebbe7cee336c8ca877a5e7388d4c65fe749c846831c1f557d6606dd15ac193bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ebbe7cee336c8ca877a5e7388d4c65fe749c846831c1f557d6606dd15ac193bc->enter($__internal_ebbe7cee336c8ca877a5e7388d4c65fe749c846831c1f557d6606dd15ac193bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_ebbe7cee336c8ca877a5e7388d4c65fe749c846831c1f557d6606dd15ac193bc->leave($__internal_ebbe7cee336c8ca877a5e7388d4c65fe749c846831c1f557d6606dd15ac193bc_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_149ab66313e2ef89446bb4b668abf868a2d63fa711d89c238bf25bc2c9b72f4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_149ab66313e2ef89446bb4b668abf868a2d63fa711d89c238bf25bc2c9b72f4f->enter($__internal_149ab66313e2ef89446bb4b668abf868a2d63fa711d89c238bf25bc2c9b72f4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_149ab66313e2ef89446bb4b668abf868a2d63fa711d89c238bf25bc2c9b72f4f->leave($__internal_149ab66313e2ef89446bb4b668abf868a2d63fa711d89c238bf25bc2c9b72f4f_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_74e5a86db84210324145f42dbbc65565f7d737e71c3adc2c73fb45c9d8bc52df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74e5a86db84210324145f42dbbc65565f7d737e71c3adc2c73fb45c9d8bc52df->enter($__internal_74e5a86db84210324145f42dbbc65565f7d737e71c3adc2c73fb45c9d8bc52df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_74e5a86db84210324145f42dbbc65565f7d737e71c3adc2c73fb45c9d8bc52df->leave($__internal_74e5a86db84210324145f42dbbc65565f7d737e71c3adc2c73fb45c9d8bc52df_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}

<?php

/* category/index.html.twig */
class __TwigTemplate_7cb4633fa1cdbf3d0d01df14bd96d6c2e5f2026f61f1024292739a71bbb49239 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "

<h4 class=\"heading_a uk-margin-bottom\">Categories list</h4>
<div class=\"md-card uk-margin-medium-bottom\">
    <div class=\"md-card-content\">
        <div class=\"uk-overflow-container\">
            <table class=\"uk-table uk-table-striped\">
                <thead>
                <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Description</th>
                <th>Type</th>
                <th>Actions</th>
             </tr>
                </thead>
                <tbody>
 
     ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 23
            echo "            <tr>
                <td><a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "description", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "type", array()), "html", null, true);
            echo "</td>


                   <td>
                          

                    <a class=\"md-fab md-fab-primary md-fab-actions\" style=\" width: 45px; height: 45px; float: left;\" href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">
                        <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">remove_red_eye</i>
                        </a>


                    <a class=\"md-fab md-fab-primary md-fab-actions\" style=\"    background: #4CAF50; width: 45px; height: 45px;float: left; margin-left: 5px; \"  href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_edit", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">
                        <i class=\"material-icons\" style=\" font-size: 23px; margin-top: -8px; \">edit</i>
                        </a>

            </td>


                
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "       </tbody>
            </table>
        </div>
    </div>
</div>





    <div class=\"md-fab-wrapper\">
                        <a class=\"md-fab md-fab-primary md-fab-actions\" href=\"";
        // line 59
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_new");
        echo "\">
                        <i class=\"material-icons\">add</i>
                        </a>
                     
                    </div>



 
";
    }

    public function getTemplateName()
    {
        return "category/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 59,  105 => 48,  89 => 38,  81 => 33,  72 => 27,  68 => 26,  64 => 25,  58 => 24,  55 => 23,  51 => 22,  31 => 4,  28 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "category/index.html.twig", "C:\\xampp\\htdocs\\symfony\\biblioProjet\\biblioProject\\app\\Resources\\views\\category\\index.html.twig");
    }
}
